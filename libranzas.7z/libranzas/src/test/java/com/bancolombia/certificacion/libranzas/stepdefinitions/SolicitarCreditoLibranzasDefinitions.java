package com.bancolombia.certificacion.libranzas.stepdefinitions;

import static com.bancolombia.certificacion.libranzas.userinterfaces.BienvenidaPage.TITULO_DE_BIENVENIDA;
import static com.bancolombia.certificacion.libranzas.userinterfaces.FinalizacionPage.ENCABEZADO_CON_NOMBRE_CLIENTE;
import static com.bancolombia.certificacion.libranzas.userinterfaces.FinalizacionPage.MENSAJE_CON_NUMERO_DE_CUENTA;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static org.hamcrest.Matchers.equalTo;

import java.util.List;

import org.openqa.selenium.WebDriver;

import com.bancolombia.certificacion.libranzas.questions.Capturando;
import com.bancolombia.certificacion.libranzas.tasks.Aceptar;
import com.bancolombia.certificacion.libranzas.tasks.Declarar;
import com.bancolombia.certificacion.libranzas.tasks.FirmaElectronicamente;
import com.bancolombia.certificacion.libranzas.tasks.IniciarLaAplicacion;
import com.bancolombia.certificacion.libranzas.tasks.NoAceptar;
import com.bancolombia.certificacion.libranzas.tasks.Quitar;
import com.bancolombia.certificacion.libranzas.tasks.SolicitandoCredito;
import com.bancolombia.certificacion.libranzas.tasks.TomaLaDecisionDe;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.thucydides.core.annotations.Managed;

public class SolicitarCreditoLibranzasDefinitions {

	@Managed(driver = "chrome", options = "--start-maximized")
	private WebDriver hisBrowser;
	private Actor actor;

	@Given("(.*) esta en la pantalla de Bienvenida$")
	public void estaEnLaPantallaDeBienvenida(String nombre) {
		actor = Actor.named(nombre);
		actor.attemptsTo(IniciarLaAplicacion.con(hisBrowser,
				"https://169.53.240.203/bancolombia.vd.libranzaFront/#informacion-general"));
		actor.attemptsTo(Quitar.barraDeCarga());
		actor.should(seeThat(Capturando.el(TITULO_DE_BIENVENIDA),
				equalTo("Bienvenido a la solicitud de tu Crédito de Libranza")));
		//orcomplainwith
	}

	@When("^el solicita un credito con los datos$")
	public void elSolicitaUnCreditoConLosDatos(List<List<String>> datos) {
		actor.attemptsTo(SolicitandoCredito.conLosDatos(datos));
	}

	@When("^declara que ha leido y conocido el pagare, y acepta el seguro de vida deudores$")
	public void declaraQueHaLeidoYConocidoElPagareYAceptaElSeguroDeVidaDeudores() {
		actor.attemptsTo(Declarar.checkPagare(), Aceptar.seguroDeVidaDeudores());
	}

	@When("^declara que ha leido y conocido el pagare, y no acepta el seguro de vida deudores inicialmente pero al ver la advertencia decide continuar$")
	public void declaraQueHaLeidoYConocidoElPagareYNoAceptaElSeguroDeVidaDeudoresInicialmentePeroAlVerLaAdvertenciaDecideContinuar() {
		actor.attemptsTo(Declarar.checkPagare(), NoAceptar.seguroDeVidaDeudores(),
				TomaLaDecisionDe.continuarConElProceso());
	}

	@When("^hace la firma electronica con la clave dinamica (.*)$")
	public void haceFirmaElectronicaConClaveDinamica(String claveDinamica) {
		actor.attemptsTo(FirmaElectronicamente.conLaClaveDinamica(claveDinamica));
	}

	@Then("^el podra ver la pantalla de confirmacion del desembolso$")
	public void elPodraVerLaPantallaDeConfirmacionDelDesembolso() {
		actor.should(seeThat(Capturando.el(ENCABEZADO_CON_NOMBRE_CLIENTE),
				equalTo("CARLOS, has terminado exitosamente la solicitud de tu Crédito de Libranza Bancolombia.")));
		actor.should(seeThat(Capturando.el(MENSAJE_CON_NUMERO_DE_CUENTA), equalTo(
				"Tu crédito ha sido desembolsado a la cuenta << número de cuenta seleccionada por el cliente>>. Recuerda revisar las condiciones del producto en el correo que te hemos enviado con los documentos.")));
	}

}
