package com.bancolombia.certificacion.libranzas.tasks;


import static com.bancolombia.certificacion.libranzas.userinterfaces.DocumentosPage.SI_ACEPTO_SEGURO;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

public class Aceptar implements Task {

	@Override
	public <T extends Actor> void performAs(T actor) {
		actor.attemptsTo(Click.on(SI_ACEPTO_SEGURO));
		actor.attemptsTo(Quitar.barraDeCarga());
		try {
			Thread.sleep(2000);
			actor.attemptsTo(Quitar.barraDeCarga());
			Thread.sleep(2000);
			actor.attemptsTo(Quitar.barraDeCarga());
		} catch (InterruptedException e) {
			e.printStackTrace();
			Thread.currentThread();
			Thread.interrupted();
		}
		
	}

	
	public static Aceptar seguroDeVidaDeudores() {
		return Tasks.instrumented(Aceptar.class);
	}
}
