package com.bancolombia.certificacion.libranzas.userinterfaces;

import net.serenitybdd.screenplay.targets.Target;

public class BienvenidaPage {
	
	public static final Target TITULO_DE_BIENVENIDA = Target.the("Titulo de Bienvenida Crédito de Libranza")
						.locatedBy("//*[contains(text(),'Bienvenido a la solicitud de tu Crédito de Libranza')]");
	public static final Target SOLICITAR_CREDITO = Target.the("Botón Solicitar Crédito")
						.locatedBy("//button[@id='see-offer']");
	public static final Target SALIR=Target.the("Botón salir").locatedBy("//li/a[contains(text(), 'Salir') ]");
}