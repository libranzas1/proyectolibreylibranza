package com.bancolombia.certificacion.libranzas.tasks;

import static com.bancolombia.certificacion.libranzas.userinterfaces.BienvenidaPage.SOLICITAR_CREDITO;
import static com.bancolombia.certificacion.libranzas.userinterfaces.InformacionOfertaPage.CALCULAR_CUOTA;
import static com.bancolombia.certificacion.libranzas.userinterfaces.InformacionOfertaPage.CONTINUAR;
import static com.bancolombia.certificacion.libranzas.userinterfaces.InformacionOfertaPage.CUENTA;
import static com.bancolombia.certificacion.libranzas.userinterfaces.InformacionOfertaPage.CUENTAS_DE_DESEMBOLSO;
import static com.bancolombia.certificacion.libranzas.userinterfaces.InformacionOfertaPage.MESES_A_PAGAR;
import static com.bancolombia.certificacion.libranzas.userinterfaces.InformacionOfertaPage.VALOR_INGRESAR;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;

public class SolicitandoCredito implements Task{

	private String monto;
	private String plazo;
	private String cuenta;
	
	public SolicitandoCredito(List<List<String>> datos) {
		monto=datos.get(1).get(0);
		plazo=datos.get(1).get(1);
		cuenta=datos.get(1).get(2);
	}
	@Override
	public <T extends Actor> void performAs(T actor) {
		actor.attemptsTo(Click.on(SOLICITAR_CREDITO	));
		
		BrowseTheWeb.as(actor).getDriver().navigate().refresh();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
			Thread.currentThread();
			Thread.interrupted();
		}
		
		actor.attemptsTo(Quitar.barraDeCarga());
		actor.attemptsTo(Quitar.barraDeCarga());
		
		actor.attemptsTo(Enter.theValue(monto).into(VALOR_INGRESAR),
						Click.on(MESES_A_PAGAR.of(plazo)),
						Click.on(CALCULAR_CUOTA));
		
		actor.attemptsTo(Quitar.barraDeCarga());
		JavascriptExecutor executor =(JavascriptExecutor)BrowseTheWeb.as(actor).getDriver();
		executor.executeScript("window.scrollBy(0,1500)", "");
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
			Thread.currentThread();
			Thread.interrupted();
		}
		
		actor.attemptsTo(Click.on(CUENTAS_DE_DESEMBOLSO),
						Click.on(CUENTA.of(cuenta)));
		try {
			Thread.sleep(2000);
			actor.attemptsTo(Click.on(CONTINUAR));
		} catch (InterruptedException e) {
			e.printStackTrace();
			Thread.currentThread();
			Thread.interrupted();
		}

		actor.attemptsTo(Quitar.barraDeCarga());
	}
	
	public static SolicitandoCredito conLosDatos(List<List<String>> datos) {
		return Tasks.instrumented(SolicitandoCredito.class, datos);
	}

}
