package com.bancolombia.certificacion.libranzas.userinterfaces;

import net.serenitybdd.screenplay.targets.Target;

public class InformacionOfertaPage {

	
	public static final Target PREAPROBADO=Target.the("Texto con el valor del Preaprobado").locatedBy("//div/app-offer/div/p");
	public static final Target VALOR_INGRESAR=Target.the("Campo del valor de crédito a solicitar").locatedBy("//*[@id=\"amount\"]");
	public static final Target MENSAJE_ERROR=Target.the("Mensaje de error cuando se ingresa el valor de crédito a solicitar").
						locatedBy("//*[@id=\"errorMessage\"]");
	public static final Target CERRAR_POPUP_VALOR_DISPONIBLE=Target.
						the("Botón para cerrar pop up de que aún se cuenta con un valor de crédito disponible").
						locatedBy("//div[2]/div/button/span");
	public static final Target MESES_A_PAGAR=Target.the("Botón para elegir los meses a pagar").locatedBy("//*[text()='{0}']");
	public static final Target CALCULAR_CUOTA=Target.the("Botón para calcular la cuota").locatedBy("//*[@id=\"btnCalculateFees\"]");
	public static final Target VALOR_CUOTA_MENSUAL=Target.the("Valor de la cuota mensual").locatedBy("//h3[2]");
	public static final Target TASA_FIJA_MV = Target.the("Tasa fija MV").locatedBy("//h3[3]");
	public static final Target SEGURO_DE_VIDA_DEUDORES=Target.the("Seguro de vida deudores").locatedBy("//td[2]/div[1]/div[1]/text()");
	public static final Target TASA_NOMINAL_MES_VENCIDO=Target.the("Tasa nominal mes vencido").locatedBy("//td[2]/div[2]/div[1]/text()");
	public static final Target TASA_EFECTIVA_ANUAL=Target.the("Tasa efectiva anual").locatedBy("//td[2]/div[3]/div[1]/text()");
	public static final Target TASA_MORA=Target.the("Tasa Mora").locatedBy("//td[2]/div[4]/div[1]/text()");
	public static final Target FECHA_DE_PAGO=Target.the("Fecha de pago").locatedBy("//td[2]/div[5]/div[1]/text()");
	public static final Target CUENTAS_DE_DESEMBOLSO=Target.the("Abrir lista para seleccionar la cuenta de desembolso").
						locatedBy("//*[@id=\"accountSelect\"]");
	public static final Target CUENTA=Target.the("Seleccionar la cuenta específica").
						locatedBy("//*[@id=\"accountSelect\"]/option[text()='{0}']");
	public static final Target CONTINUAR=Target.the("Botón Continuar que avanza a la pantalla de los documentos").
						locatedBy("/html/body/app-root/div/app-offer/form/div[5]/button[2]");
	public static final Target CANCELAR=Target.the("Botón Cancelar que finaliza la experiencia").locatedBy("//div[4]/button[1]");
}
