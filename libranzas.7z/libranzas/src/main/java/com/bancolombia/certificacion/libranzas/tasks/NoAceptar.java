package com.bancolombia.certificacion.libranzas.tasks;

import static com.bancolombia.certificacion.libranzas.userinterfaces.DocumentosPage.*;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

public class NoAceptar implements Task{
	

	@Override
	public <T extends Actor> void performAs(T actor) {
		actor.attemptsTo(Click.on(NO_ACEPTO_SEGURO));
	}

	
	public static NoAceptar seguroDeVidaDeudores() {
		return Tasks.instrumented(NoAceptar.class);
	}

}
