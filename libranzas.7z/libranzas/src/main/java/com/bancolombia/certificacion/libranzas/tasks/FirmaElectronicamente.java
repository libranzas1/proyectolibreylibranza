package com.bancolombia.certificacion.libranzas.tasks;

import static com.bancolombia.certificacion.libranzas.userinterfaces.DocumentosPage.BOTON_FINALIZAR;
import static com.bancolombia.certificacion.libranzas.userinterfaces.DocumentosPage.INGRESAR_CLAVE_DINAMICA;

import org.openqa.selenium.JavascriptExecutor;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;

public class FirmaElectronicamente implements Task {
	
	private String claveDinamica;
	
	public FirmaElectronicamente(String claveDinamica) {
		this.claveDinamica= claveDinamica;
	}

	@Override
	public <T extends Actor> void performAs(T actor) {
		JavascriptExecutor executor =(JavascriptExecutor)BrowseTheWeb.as(actor).getDriver();
		executor.executeScript("window.scrollBy(0,1500)", "");
		
		actor.attemptsTo(Enter.theValue(claveDinamica).into(INGRESAR_CLAVE_DINAMICA), Click.on(BOTON_FINALIZAR));
		try {
			Thread.sleep(5000);
			actor.attemptsTo(Quitar.barraDeCarga());
			
		} catch (InterruptedException e) {
			e.printStackTrace();
			Thread.currentThread();
			Thread.interrupted();
		}
	}

	public static FirmaElectronicamente conLaClaveDinamica(String claveDinamica) {
		return Tasks.instrumented(FirmaElectronicamente.class, claveDinamica);
	}
}
