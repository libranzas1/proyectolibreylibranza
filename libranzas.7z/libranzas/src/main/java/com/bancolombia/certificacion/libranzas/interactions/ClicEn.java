package com.bancolombia.certificacion.libranzas.interactions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.targets.Target;

public class ClicEn implements Interaction{
	
	private Target target;
	
	public ClicEn(Target target) {
		this.target = target;
	}

	@Override
	public <T extends Actor> void performAs(T actor) {
		actor.attemptsTo(Click.on(target));
		
	}
	
	public static ClicEn elBoton(Target target) {
		return Tasks.instrumented(ClicEn.class,target);
	}

}
