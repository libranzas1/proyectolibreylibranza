package com.bancolombia.certificacion.libranzas.userinterfaces;

import net.serenitybdd.screenplay.targets.Target;

public class FinalizacionPage  {
	
	public static final Target  ENCABEZADO_CON_NOMBRE_CLIENTE = Target.the("Encabezado donde contiene el nombre del cliente")
			.locatedBy("//strong");
	
	public static final Target MENSAJE_CON_NUMERO_DE_CUENTA = Target.the("Mensaje donde aparece la cuenta donde se hizo el desembolso")
			.locatedBy("/html/body/app-root/div/app-success/div[1]/p[2]");	
	
	public static final Target BOTON_CERRAR = Target.the("Boton donde cierra la experiencia luego del desembolso")
			.locatedBy("//button[@class='btn btn-primary btn-full']");

}
