package com.bancolombia.certificacion.libranzas.tasks;

import static com.bancolombia.certificacion.libranzas.userinterfaces.DocumentosPage.CHECK_PAGARE;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

public class Declarar implements Task {

	@Override
	public <T extends Actor> void performAs(T actor) {
		actor.attemptsTo(Quitar.barraDeCarga());
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
			Thread.currentThread();
			Thread.interrupted();
		}
		actor.attemptsTo(Click.on(CHECK_PAGARE));
	}
	
	
	public static Declarar checkPagare() {
		return Tasks.instrumented(Declarar.class);
	}

}
