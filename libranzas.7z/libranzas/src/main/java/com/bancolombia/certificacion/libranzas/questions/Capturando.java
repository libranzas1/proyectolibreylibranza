package com.bancolombia.certificacion.libranzas.questions;

import com.bancolombia.certificacion.libranzas.tasks.Quitar;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;
import net.serenitybdd.screenplay.targets.Target;

public class Capturando implements Question<String>{
	
	private Target target;
	
	public Capturando(Target target) {
		this.target=target;
	}
		
	@Override
	public String answeredBy(Actor actor) {
		try {
			Thread.sleep(3000);
			actor.attemptsTo(Quitar.barraDeCarga());
			
		} catch (InterruptedException e) {
			
			e.printStackTrace();
			Thread.currentThread();
			Thread.interrupted();
		}
		return Text.of(target).viewedBy(actor).asString();
		
	}
	
	public static Capturando el(Target target) {
		return new Capturando(target);
	}

}
