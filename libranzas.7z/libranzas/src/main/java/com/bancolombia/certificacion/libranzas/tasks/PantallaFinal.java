package com.bancolombia.certificacion.libranzas.tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.questions.Text;
import static com.bancolombia.certificacion.libranzas.userinterfaces.FinalizacionPage.*;

public class PantallaFinal implements Task{

	@Override
	public <T extends Actor> void performAs(T actor) {
		String encabezado = Text.of(ENCABEZADO_CON_NOMBRE_CLIENTE).viewedBy(actor).value();
		System.out.println(encabezado);
		
	}

	public static  PantallaFinal proceso() {
		return Tasks.instrumented(PantallaFinal.class);
	}
}
