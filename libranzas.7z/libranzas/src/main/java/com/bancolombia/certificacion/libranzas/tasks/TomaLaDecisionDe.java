package com.bancolombia.certificacion.libranzas.tasks;

import static com.bancolombia.certificacion.libranzas.userinterfaces.DocumentosPage.BOTON_SI_DEL_POPUP_NO_ACEPTO;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

public class TomaLaDecisionDe implements Task {

	@Override
	public <T extends Actor> void performAs(T actor) {
		actor.attemptsTo(Click.on(BOTON_SI_DEL_POPUP_NO_ACEPTO));
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
			Thread.currentThread();
			Thread.interrupted();
		}
	}

	public static TomaLaDecisionDe continuarConElProceso() {
		return Tasks.instrumented(TomaLaDecisionDe.class);
	}
}
