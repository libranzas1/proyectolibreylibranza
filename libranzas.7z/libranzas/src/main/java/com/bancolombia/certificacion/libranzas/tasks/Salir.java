package com.bancolombia.certificacion.libranzas.tasks;

import static com.bancolombia.certificacion.libranzas.userinterfaces.DocumentosPage.BOTON_NO_DEL_POPUP_NO_ACEPTO;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

public class Salir implements Task {

	@Override
	public <T extends Actor> void performAs(T actor) {
		actor.attemptsTo(Click.on(BOTON_NO_DEL_POPUP_NO_ACEPTO));
	}

	public static Salir deLaExperiencia() {
		return Tasks.instrumented(Salir.class);
	}

}
