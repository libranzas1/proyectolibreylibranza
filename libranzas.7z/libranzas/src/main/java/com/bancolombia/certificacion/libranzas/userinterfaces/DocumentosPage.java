package com.bancolombia.certificacion.libranzas.userinterfaces;

import net.serenitybdd.screenplay.targets.Target;

public class DocumentosPage {

	public static final Target TITULO_DE_DOCUMENTOS = Target.the("Título pantalla de documentos")
			.locatedBy("//*[@id=\"titleDocs\"]");
	public static final Target VER_PAGARE = Target.the("Mensaje para motrar el pagare del usuario")
			.locatedBy("//a[@id='linkPagareId']");
	public static final Target CHECK_PAGARE = Target.the("Check que confirma que ya se ha leido el pagare")
			.locatedBy("//*[@id='acept2']");

	public static final Target SI_ACEPTO_SEGURO = Target.the("Check que afirma aceptar el seguro de vida deudores")
			.locatedBy("//label[@class='radio-inline']/input[@id='inlineRadio1']");

	public static final Target NO_ACEPTO_SEGURO = Target
			.the("Check que indica que no acepta el seguro de vida deudores")
			.locatedBy("//label[@class='radio-inline']/input[@id='inlineRadio2']");

	public static final Target BOTON_SI_DEL_POPUP_NO_ACEPTO = Target
			.the("Botón Sí del PopUp, para continuar con la solicitud y aceptar el seguro de vida Deudores")
			.locatedBy("/html/body/modal-container/div/div/div/div[3]/button[2]");

	public static final Target BOTON_NO_DEL_POPUP_NO_ACEPTO = Target
			.the("Botón No del PopUp, para no continuar con la solicitud y no aceptar el seguro de vida Deudores")
			.locatedBy("/html/body/modal-container/div/div/div/div[3]/button[1]");

	public static final Target EQUIS_POPUP_NO_ACEPTO = Target.the("Equis que permite seguir con la experiencia")
			.locatedBy("//button[@class='close']/span");

	public static final Target INGRESAR_CLAVE_DINAMICA = Target.the("Input para ingresar la clave dinámica")
			.locatedBy("//input[@id='inputOtp']");

	public static final Target GENERAR_NUEVA_CLAVE_DINAMICA = Target.the("Botón para generar una nueva clave dinámica")
			.locatedBy("//a[@id='newOtp']");

	public static final Target BOTON_CANCELAR = Target.the("Botón cancelar el proceso del crédito")
			.locatedBy("//button[contains(text(), 'Cancelar')]");
	
	
	public static final Target BOTON_FINALIZAR = Target.the("Botón finalizar el proceso del crédito")
			.locatedBy("//button[@type='submit']");
	
	
	
}