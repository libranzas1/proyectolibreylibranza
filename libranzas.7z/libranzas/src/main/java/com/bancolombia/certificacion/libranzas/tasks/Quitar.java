package com.bancolombia.certificacion.libranzas.tasks;

import java.awt.Robot;
import java.awt.event.KeyEvent;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;

public class Quitar implements Task{

	
	@Override
	public <T extends Actor> void performAs(T actor) {
		 try {
			 Robot robot = new Robot();
			 robot.keyPress(KeyEvent.VK_ESCAPE);
			
			 } catch (Exception e) {
			 System.out.println(e);
			 } 
	}
	
	public static Quitar barraDeCarga() {
		return Tasks.instrumented(Quitar.class);
	}

}
