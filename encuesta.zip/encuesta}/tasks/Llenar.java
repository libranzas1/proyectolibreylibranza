package com.bancolombia.certificacion.libranzas.tasks;

import static com.bancolombia.certificacion.libranzas.userinterfaces.EncuestaPage.*;
import static com.bancolombia.certificacion.libranzas.userinterfaces.FinalizacionPage.BOTON_CERRAR;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;

public class Llenar implements Task {

	@Override
	public <T extends Actor> void performAs(T actor) {

		try {
			Thread.sleep(6000);
			actor.attemptsTo(

					Click.on(BOTON_CERRAR), Click.on(ESTRELLAS), Click.on(OPCIONES),

					Enter.theValue("muy bueno").into(COMENTARIO),

					Click.on(BOTON_ENVIAR)

			);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static Llenar encuestaAlFinal() {
		return Tasks.instrumented(Llenar.class);
	}
}
