package com.bancolombia.certificacion.libranzas.userinterfaces;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;

public class EncuestaPage extends PageObject {

	public static final Target ESTRELLAS = Target.the("Boton para elegir estrella").locatedBy("//span[@title='five']");

	public static final Target OPCIONES = Target.the("Opciones para elegir luego de escoger estrellas")
			.locatedBy("/html/body/modal-container/div/div/div[2]/div/div[2]/div[1]/div/div/button[1]");

	public static final Target COMENTARIO = Target.the("comentario").locatedBy("//*[@id=\"comment \"]");
	
	public static final Target BOTON_ENVIAR = Target.the("boton_enviar").locatedBy("/html/body/modal-container/div/div/div[3]/button");
}
