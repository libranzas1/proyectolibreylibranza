package com.bancolombia.preaprobado.libreinversion;

import java.io.FileNotFoundException;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bancolombia.preaprobado.libreinversion.pages.BackendAs400db2Page;
import com.bancolombia.preaprobado.libreinversion.utilities.Conection;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws SQLException, FileNotFoundException
    {
      
    	BackendAs400db2Page page = new BackendAs400db2Page();
    	String documento="967807";
    	String consulta = page.Consultar_Clave_Dinamica(documento);
    	ResultSet rs = page.Ejecutar_Query(consulta);	
		page.Obtener_Clave_Dinamica(rs );
    	System.out.println(page.Obtener_Clave_Dinamica(rs ));
    	
    }
}
