package com.bancolombia.preaprobado.libreinversion.definitions;

import com.bancolombia.preaprobado.libreinversion.steps.BackendAs400db2Steps;

import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Steps;

public class BackendAs400db2LimiteDefinition {

	@Steps
	BackendAs400db2Steps BackendAs400db2Steps;
	
	@Given("^verifico el limite inicial (\\d+)$")
	public void verifico_el_limite_inicial(String strDocumento) throws Exception {
	    BackendAs400db2Steps.Consulta_CNAME(strDocumento);
		BackendAs400db2Steps.Armar_Query_Consulta_XCRL();
	}


	@Given("^Vuelvo a verificar el limite final (\\d+)$")
	public void vuelvo_a_verificar_el_limite_final(String strDocumento) throws Exception {
		BackendAs400db2Steps.Consulta_CNAME(strDocumento);
		BackendAs400db2Steps.Armar_Query_Consulta_XCRL_limite();
	    
	}
	
}
	
	

