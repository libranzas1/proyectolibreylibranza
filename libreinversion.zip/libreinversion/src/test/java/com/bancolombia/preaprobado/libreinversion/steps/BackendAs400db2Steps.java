package com.bancolombia.preaprobado.libreinversion.steps;

import java.sql.ResultSet;
import java.util.List;
import  com.bancolombia.preaprobado.libreinversion.pages.BackendAs400db2Page;

import jnr.ffi.Struct.int32_t;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;

public class BackendAs400db2Steps extends ScenarioSteps {
	
	BackendAs400db2Page  BackendAs400db2Page;

	@Step
	public void Consultar_COMFFLGBV(List<List<String>> data) throws Exception {
	
		String strDocumento = data.get(0).get(0);			
		String strTransaccion = data.get(0).get(3);
		String strPlan = data.get(0).get(7);
		String strTipoMensaje = data.get(0).get(26);
 
		String query = BackendAs400db2Page.Armar_Query_Consulta_COMFFLGBVL(strDocumento,strTransaccion,strTipoMensaje,strPlan);
	    ResultSet rs = BackendAs400db2Page.Ejecutar_Query(query);
	    
	    BackendAs400db2Page.Verificar_Consulta_COMFFLGBVL(rs, data);
	}
	
	
	@Step
	 public void Consultar_LMBAL(List<List<String>> data) throws Exception {
  	  String strDocumento = data.get(0).get(0);
        String query = BackendAs400db2Page.Armar_Query_Consulta_LMBAL(strDocumento);
        ResultSet rs = BackendAs400db2Page.Ejecutar_Query(query);
        BackendAs400db2Page.Verificar_Consulta_LMBAL(rs, data);
  }
	
	
	
	@Step	
	public void Consulta_CNAME(String strDocumento) throws Exception {
		try {
//			
//			String query = BackendAs400db2Page.Consulta_CNAME(strDocumento);		
//			ResultSet rs = BackendAs400db2Page.Ejecutar_Query(query);		
//			BackendAs400db2Page.Verificar_Consulta_CNAME(rs);	
			BackendAs400db2Page.Consultar_cname_unificado(strDocumento);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Step
	public void  Armar_Query_Consulta_XCRL() throws Exception {
		try {
			String query = BackendAs400db2Page.Armar_Query_Consulta_XCRL();
			ResultSet rs = BackendAs400db2Page.Ejecutar_Query(query);	
			BackendAs400db2Page.Verificar_Consulta_XCRL(rs);			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Step
	public void  Armar_Query_Consulta_XCRL_limite() throws Exception {
		try {
			String query = BackendAs400db2Page.Armar_Query_Consulta_XCRL();
			ResultSet rs = BackendAs400db2Page.Ejecutar_Query(query);	
			BackendAs400db2Page.Verificar_Consulta_XCRL_Limite(rs);			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Step
	public void Consultar_clavedinamica(String strDocumento) throws Exception {
		try {
			String query = BackendAs400db2Page.Consultar_Clave_Dinamica(strDocumento);
			ResultSet rs = BackendAs400db2Page.Ejecutar_Query(query);	
			BackendAs400db2Page.Obtener_Clave_Dinamica(rs);
			System.out.println(BackendAs400db2Page.Obtener_Clave_Dinamica(rs));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Step
	public void Armar_Query_Consulta_Precalculado(String strDocumento)throws Exception {
		try {
			String query = BackendAs400db2Page.Consultar_BasePrecalculado(strDocumento);
			ResultSet rs = BackendAs400db2Page.Ejecutar_Query_Oracle(query);
			BackendAs400db2Page.Recorrer_BasePrecalculado(rs);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Step
	public void Armar_Query_Consulta_correotel(List<List<String>> data)throws Exception {
		try {
			String strDocumento = data.get(0).get(0);
			String query = BackendAs400db2Page.Armar_query_Consulta_tel_email(strDocumento);
			ResultSet rs = BackendAs400db2Page.Ejecutar_Query(query);
			BackendAs400db2Page.Consultar_Correo_tel(rs);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
		
}
