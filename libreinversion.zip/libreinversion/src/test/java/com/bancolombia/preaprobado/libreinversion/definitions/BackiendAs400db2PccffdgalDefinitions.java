package com.bancolombia.preaprobado.libreinversion.definitions;

import java.util.List;

import com.bancolombia.preaprobado.libreinversion.steps.AutenticaSteps;
import com.bancolombia.preaprobado.libreinversion.steps.BackendAs400db2Steps;
import com.bancolombia.preaprobado.libreinversion.utilities.ExcelReader;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Steps;

public class BackiendAs400db2PccffdgalDefinitions {

	@Steps
	BackendAs400db2Steps BackendAs400db2Steps;

	@Given("^valido los datos de PCCFFDGAL$")
	public void valido_los_datos_de_PCCFFDGAL(DataTable Documento) throws Exception {
		List<List<String>> data = Documento.raw();
		BackendAs400db2Steps.Armar_Query_Consulta_correotel(data);
				
	}

	
}
