package com.bancolombia.preaprobado.libreinversion.definitions;

import com.bancolombia.preaprobado.libreinversion.steps.BackendAs400db2Steps;

import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Steps;

public class BackiendAs400db2CnameDefinitions {
	@Steps
	BackendAs400db2Steps backendAs400db2Steps;
	
	@Given("^valido los datos del nombre precalculado (\\d+)$")
	public void valido_los_datos_del_nombre_precalculado(String strDocumento) throws Exception {
	    
		backendAs400db2Steps.Consulta_CNAME(strDocumento);
	}
	
	
}
