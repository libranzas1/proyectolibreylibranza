package com.bancolombia.preaprobado.libreinversion.definitions;

import java.util.List;

import com.bancolombia.preaprobado.libreinversion.steps.BackendAs400db2Steps;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Steps;

public class BackendAs400db2Definition {

	@Steps
	BackendAs400db2Steps BackendAs400db2Steps;
	
	
	@Given("^que estoy consultando el archivo COMFFLGBVL y LMBAL$")
	public void que_estoy_consultando_el_archivo_COMFFLGBVL_y_LMBAL(DataTable dtDatosPrueba) throws Exception {
	 List<List<String>> data = dtDatosPrueba.raw();
	 BackendAs400db2Steps.Consultar_COMFFLGBV(data);
	 BackendAs400db2Steps.Consultar_LMBAL(data);
	}
	
	
	
//	@Given("^verifico el limite (\\d+)$")
//	public void verifico_el_limite(String strDocumento) throws Exception {
//		BackendAs400db2Steps.Consulta_CNAME(strDocumento);
//		BackendAs400db2Steps.Armar_Query_Consulta_XCRL();
//	}
//
//	@Given("^Vuelvo a verificar el limite (\\d+)$")
//	public void vuelvo_a_verificar_el_limite(String strDocumento) throws Exception {
//		BackendAs400db2Steps.Consulta_CNAME(strDocumento);
//		BackendAs400db2Steps.Armar_Query_Consulta_XCRL_limite();
//	 
//	}
}
