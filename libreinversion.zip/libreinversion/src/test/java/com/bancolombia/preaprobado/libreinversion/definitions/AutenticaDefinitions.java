package com.bancolombia.preaprobado.libreinversion.definitions;


import java.util.List;

import com.bancolombia.preaprobado.libreinversion.steps.AutenticaSteps;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class AutenticaDefinitions {
	
	@Steps
	AutenticaSteps autenticacionoauth;
	
	@Given("^que me encuentro en la autenticacion oauth de Libre Inversión$")
	public void que_me_encuentro_en_la_autenticacion_oauth_de_Libre_Inversión() throws Exception {
	   //String path = Serenity.sessionVariableCalled("C:\\Users\\Usuario.DESKTOP-HN86BQH\\Desktop\\dtDatos.xlsx").toString();
		autenticacionoauth.abrirAutentica();
	}


	@When("^Ingreso los datos de \"([^\"]*)\" y \"([^\"]*)\"$")
	public void ingreso_los_datos_de_y(String Usuario, String Contrasena) throws Exception {
	   
		autenticacionoauth.ingresarDatos(Usuario, Contrasena);
	}
	
	@When("^verifico el limite (\\d+)$")
	public void verifico_el_limite(String strDocumento) throws Exception {
		autenticacionoauth.Consulta_CNAME(strDocumento);
		autenticacionoauth.Armar_Query_Consulta_XCRL();
	}

	@When("^Seleccionar producto credito libre inversion (\\d+)$")
	public void seleccionar_producto_credito_libre_inversion(String strDocumento) throws Exception {
		autenticacionoauth.obtenerNombrecliente(strDocumento);	
		autenticacionoauth.Armar_Query_Consulta_Precalculado(strDocumento);
		autenticacionoauth.clicbotonIngresar();
	}

	@When("^Solicitar credito de libre inversion$")
	public void solicitar_credito_de_libre_inversion() throws Exception {
	   
		autenticacionoauth.clicbotonSolcitar();
	}

	@When("^Ingresar  datos de \"([^\"]*)\" y \"([^\"]*)\"$")
	public void ingresar_datos_de_y(String Cupo, String Plazo) throws Exception {
	    
		autenticacionoauth.calcularCuota(Cupo, Plazo);
	}

	@When("^verificar nombre en la oferta (\\d+)$")
	public void verificar_nombre_en_la_oferta(String strDocumento) throws Exception {
	    
		autenticacionoauth.obtenerNombreclienteoferta(strDocumento);
	}
	@When("^Definir cuenta \"([^\"]*)\"$")
	public void definir_cuenta_y(String Desembolso) throws Exception {
	    
		autenticacionoauth.seleccionarNumerodeCuenta(Desembolso);
	}
	
	@When("^Desea usar debito automatico (.*) y cuenta \"([^\"]*)\"$")
	public void desea_usar_debito_automatico_y_cuenta(String Desicion, String Debito) throws Exception {
	    
		autenticacionoauth.usarServicioAutomatico(Desicion, Debito);
	}

	@When("^Verpagare y documentos$")
	public void verpagare_y_documentos() throws Exception {
		autenticacionoauth.verPagareydocumentos();
	 
	}
	
	
    @When("^Aceptar \"([^\"]*)\"$")
	public void aceptar_si_y_y_no(String Seguro) throws Exception {
	   
		autenticacionoauth.aceptarSeguro(Seguro);
	}
    
    @When("^validando los datos del iseries (\\d+)$")
	public void validando_los_datos_del_iseries(String strDocumento) throws Exception {
	    
    	autenticacionoauth.Consulta_Clave_Dinamica(strDocumento);
	}
    
    @When("^estoy consultando el archivo COMFFLGBVL y LMBAL$")
	public void estoy_consultando_el_archivo_COMFFLGBVL_y_LMBAL(DataTable dtDatosPrueba) throws Exception {
	 List<List<String>> data = dtDatosPrueba.raw();
	 autenticacionoauth.Consultar_COMFFLGBV(data);
	 autenticacionoauth.Consultar_LMBAL(data);
	}
    

	@Then("^Verificar solicitud exitosa de credito$")
	public void verificar_solicitud_exitosa_de_credito() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		autenticacionoauth.finalizarcontenido();
	}	
	
	
	@Then("^Calificar la experiencia$")
	public void calificar_la_experiencia() throws Exception {
		autenticacionoauth.calificatuexperiencia();
	
	}
	
	@Then("^Vuelvo a verificar el limite (\\d+)$")
	public void vuelvo_a_verificar_el_limite(String strDocumento) throws Exception {
		autenticacionoauth.Consulta_CNAME(strDocumento);
		autenticacionoauth.Armar_Query_Consulta_XCRL_limite();
	 
	}

	@Then("^Solicitud Realizada$")
	public void solicitud_Realizada() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^Regresar al dashboard$")
	public void regresar_al_dashboard() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    
	}


}
