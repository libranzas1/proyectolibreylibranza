package com.bancolombia.preaprobado.libreinversion;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import java.io.IOException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.runner.RunWith;
import com.bancolombia.preaprobado.libreinversion.utilities.BeforeSuite;
import com.bancolombia.preaprobado.libreinversion.utilities.DataToFeature;
import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;


@RunWith(CucumberWithSerenity.class)
//@CucumberOptions(
//  features = { "classpath:features/autenticacion/autenticar.feature" },
//  glue = {"com.bancolombia.preaprobado.libreinversion.definitions" })
@CucumberOptions(features="src/test/resources/features/Test_Front_LI/ExperienciaPreaprobadosLI.feature",tags="@ValidacionexitosaOferta")
//@CucumberOptions(features="src/test/resources/features/Test_Back_LI/Consulta_Archivos_Cartera.feature",tags="@ValidacionLogymaestrodePrestamos")
//@CucumberOptions(features="src/test/resources/features/Test_Back_LI/Consulta_Bd_Precalculado.feature",tags="@ValidacinTablaPrecalculado")
// @CucumberOptions(features="src/test/resources/features/Test_Back_LI/Clave_dinamica.feature",tags="@Validacionclavedinamica")
//@CucumberOptions(features="src/test/resources/features/Test_Back_LI/Consulta_Archivo_Cname.feature",tags="@Validacionnombre")
//@CucumberOptions(features="src/test/resources/features/Test_Back_LI/Consulta_Archivo_Pccffdgal.feature",tags="@Validaciontelycorreo")
//@CucumberOptions(features="src/test/resources/features/Test_Back_LI/Consulta_Archivo_limite.feature",tags="@ValidacionLimite")


public class Runner {
	
}
