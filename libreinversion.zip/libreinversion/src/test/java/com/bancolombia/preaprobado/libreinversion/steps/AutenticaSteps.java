package com.bancolombia.preaprobado.libreinversion.steps;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.List;

import org.fluentlenium.core.annotation.Page;

import com.bancolombia.preaprobado.libreinversion.pages.AutenticaPages;
import com.bancolombia.preaprobado.libreinversion.pages.BackendAs400db2Page;
import com.bancolombia.preaprobado.libreinversion.pages.DashboardPages;
import com.bancolombia.preaprobado.libreinversion.pages.DocumentosPages;
import com.bancolombia.preaprobado.libreinversion.pages.EncuestaPages;
import com.bancolombia.preaprobado.libreinversion.pages.OfertaPages;
import com.bancolombia.preaprobado.libreinversion.pages.RequisitosPages;
import com.bancolombia.preaprobado.libreinversion.pages.SolicitudExitosaPages;
import com.bancolombia.preaprobado.libreinversion.utilities.ExcelReader;
import com.headius.invokebinder.transform.Catch;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.pages.Pages;
import net.thucydides.core.steps.ScenarioSteps;

public class AutenticaSteps extends ScenarioSteps {
	
	@Page
	AutenticaPages Autentica;
	DashboardPages solicita;
    RequisitosPages requisitos;
    OfertaPages oferta;
    DocumentosPages documentos;
    SolicitudExitosaPages solicitud;
    EncuestaPages Encuesta;
    BackendAs400db2Page Back;
  
    
	public AutenticaSteps(Pages pages) {
		super(pages);
		// TODO Auto-generated constructor stub
	}

	@Step
	public void abrirAutentica() {
		Autentica.open();
	}
	
	@Step
	public void ingresarDatos(String Usuario, String Contrasena) throws InterruptedException, IOException  {
		try {
			Autentica.Autenticacionoauth(Usuario, Contrasena);
	}catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	
	@Step
	public void clicbotonIngresar() throws InterruptedException, IOException  {
		try {
			
			solicita.presionarBotonSolicitar();
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
	
	@Step
	public void clicbotonSolcitar() throws InterruptedException, IOException  {
		try {
			requisitos.presionarBotonSolicitarCredito();
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
	@Step
	public void calcularCuota(String Cupo, String Plazo)throws InterruptedException, IOException {
	try {
		oferta.calcularCuota(Cupo, Plazo);
	    }catch(Exception e) {
		    e.printStackTrace();
		}
	
	}
	
	@Step
	public void seleccionarNumerodeCuenta(String Desembolso)throws InterruptedException, IOException {
	try {
		oferta.seleccionarNumerodeCuenta(Desembolso);
	    }catch(Exception e) {
		    e.printStackTrace();
		}
	
	}
	
	@Step
	public void usarServicioAutomatico(String Desicion, String Debito)throws InterruptedException, IOException {
		try {
			oferta.usarServicioAutomatico(Desicion, Debito);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Step
	public void verPagareydocumentos()throws InterruptedException, IOException {
		try {
			documentos.verPagareydocumentos();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	@Step
	public void aceptarSeguro(String Seguro) throws InterruptedException, IOException {
	try {	
		documentos.aceptarSeguro(Seguro);
	} catch (Exception e) {
		e.printStackTrace();
	}
   }
	
	
	@Step
	public void finalizarcontenido()throws InterruptedException, IOException{
		try {
			solicitud.finalizarcontenido();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Step
	public void calificatuexperiencia ()throws InterruptedException, IOException{
		try {
			
			Encuesta.calificatuexperiencia();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Step
	public void Consulta_Clave_Dinamica(String strDocumento)throws Exception {
		documentos.claveDinamica(strDocumento);
				
	}
	
	
	@Step
	public void obtenerNombrecliente(String strDocumento)throws Exception {
		solicita.obtenerNombrecliente(strDocumento);
	}
	
	@Step
	public void obtenerNombreclienteoferta(String strDocumento)throws Exception {
		oferta.obtenerNombreclienteoferta(strDocumento);
	}
	
	
	@Step	
	public void Consulta_CNAME(String strDocumento) throws Exception {
		try {
			String query = Back.Consulta_CNAME(strDocumento);
			ResultSet rs = Back.Ejecutar_Query(query);	
			Back.Verificar_Consulta_CNAME(rs);			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Step
	public void  Armar_Query_Consulta_XCRL() throws Exception {
		try {
			String query = Back.Armar_Query_Consulta_XCRL();
			ResultSet rs = Back.Ejecutar_Query(query);	
			Back.Verificar_Consulta_XCRL(rs);			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Step
	public void  Armar_Query_Consulta_XCRL_limite() throws Exception {
		try {
			String query = Back.Armar_Query_Consulta_XCRL();
			ResultSet rs = Back.Ejecutar_Query(query);	
			Back.Verificar_Consulta_XCRL_Limite(rs);			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Step
	public void Armar_Query_Consulta_Precalculado(String strDocumento)throws Exception {
		try {
			solicita.compararCupoprecalculado(strDocumento);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	@Step
	public void ConsultaTelynombre(String strDocumento )throws Exception {
		try {
			
			String query = Back.Armar_query_Consulta_tel_email(strDocumento);
			ResultSet rs = Back.Ejecutar_Query(query);	
			Back.Consultar_Correo_tel(rs);				
				
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Step
	public void Consultar_COMFFLGBV(List<List<String>> data) throws Exception {
	
		String strDocumento = data.get(0).get(0);			
		String strTransaccion = data.get(0).get(3);
		String strTipoMensaje = data.get(0).get(26);
		String strPlan = data.get(0).get(7);
		String query = Back.Armar_Query_Consulta_COMFFLGBVL(strDocumento,strTransaccion,strTipoMensaje,strPlan);
	    ResultSet rs = Back.Ejecutar_Query(query);
	    
	    Back.Verificar_Consulta_COMFFLGBVL(rs, data);
	}
	
	
	@Step
	 public void Consultar_LMBAL(List<List<String>> data) throws Exception {
  	  String strDocumento = data.get(0).get(0);
        String query = Back.Armar_Query_Consulta_LMBAL(strDocumento);
        ResultSet rs = Back.Ejecutar_Query(query);
        Back.Verificar_Consulta_LMBAL(rs, data);
  }
	
}