package com.bancolombia.preaprobado.libreinversion.pages;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.collections.set.SynchronizedSortedSet;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

import com.bancolombia.preaprobado.libreinversion.utilities.ExcelReader;
import com.bancolombia.preaprobado.libreinversion.utilities.Sql_Execute;
import com.bancolombia.preaprobado.libreinversion.utilities.Sql_Execute_Oracle;

import net.serenitybdd.core.pages.PageObject;

public class BackendAs400db2Page extends PageObject {

Date fechaActual = new Date();
DateFormat formatoFecha = new SimpleDateFormat("yyyyMMdd");
String fecha = formatoFecha.format(fechaActual);

XSSFWorkbook workbook = new XSSFWorkbook(); 

//Variables globales
String strPrestamo;
int Monto_contrato;
int Monto_retiro;
int Monto_total;
String Monto_retiro_limite; 
String llave_nombre;
String tipo_credito = "OPE";
String cod_actividad = "1";
String Clave_dinamica;
String Cod_produc="14";
String strNombreC;
String strCodigoDes;
String strCodigoDeb;
String strPlazo;
String strTasa;
String strTasaSV;
String strFechaDes;
String strFechaV;
String strNroCuentaDes;
String strNroCuentaDeb;
String strValorCuota;
String strMontoTotal;
String strNroCaso;
String Nombre;
String Nombre_corto;
String Cupo_Recibido;
int intNroSec;

//Metodo que arma el query del log COMFFLGBVL, donde quedan las transaciones de un desembolso de libre inversiòn
public String Armar_Query_Consulta_COMFFLGBVL(String strDocumento, String strTransaccion, String strTipoMensaje, String strplan) {
	//String strQuery = "SELECT * FROM  VISIONR.CNAME WHERE CNNOSS = '<documento>'";
	String strQuery ="SELECT substr(MENSAJE,180+7297,15)Id_Cliente,FECHA,substr(hora,1,6) hora,substr(MENSAJE, 93, 4)transaccion," +
	         "substr(MENSAJE, 118, 4)Codigo,substr(MENSAJE, 180 + 3, 3)Ofi_Origen,substr(MENSAJE, 180 + 17, 10)Prestamo," +
			 "substr(MENSAJE, 180 + 49,3)plan,substr(MENSAJE, 180 + 78, 5) Oficial_Original,substr(MENSAJE, 180 + 123, 1) Tipo_Cta_Desembolso," + 
			 "substr(MENSAJE, 180 + 124, 1)Tipo_Cta_Debito,substr(MENSAJE, 180 + 126, 1)Codigo_BaseAnual,substr(MENSAJE, 180 + 130, 1)Codigo_FrecPago," +
			 "substr(MENSAJE, 180 + 143, 1)Garantia,substr(MENSAJE, 180 + 149, 1)Estado_Prestamo,substr(MENSAJE, 180 + 323, 2)Plazo," +
			 "substr(MENSAJE, 180 + 381, 7)Tasa,substr(MENSAJE, 180 + 402, 10) Tasa_SV,substr(MENSAJE, 180++680, 8)Fecha_Apertura," +
			 "substr(MENSAJE, 180 + 824, 8)Fecha_Vencimiento,substr(MENSAJE, 180 + 1148, 11)Cta_Desembolso,substr(MENSAJE, 180 + 1159, 1)Codigo_PagoA,"+
			 "substr(MENSAJE, 180 + 1160, 11)Cta_Debito_Automatico,substr(MENSAJE, 180 + 4361, 15)Valor_Cuota,substr(MENSAJE, 180 + 5395, 15)Monto_TotalC,"+
			 "substr(MENSAJE, 180 + 6823, 3)Canal_Origen,TIPOMSG,substr(MENSAJE,180+7015,40)Identif_Desembolso,substr(MENSAJE, 180 + 7376, 13)Mum_Rastreo," +
			 "substr(MENSAJE, 180 + 7402, 5)Ind_revers,substr(MENSAJE, 180 + 7432, 5)Nro_Sec," +
			 "substr(MENSAJE, 180 + 10001, 70)Mensaje_Error FROM COMLIBRAMD.COMFFLGBVL  X WHERE substr(MENSAJE, 93, 4) = '<transaccion>' AND TIPOMSG = '<TipoMensaje>' AND " + 
			 "substr(MENSAJE, 180  + 7297, 15)='<Identificacion>' AND FECHA='"+ fecha + "' AND substr(MENSAJE, 180 + 49,3) ='<plan>' ORDER BY substr(hora,1,6) DESC LIMIT 1";
strQuery = strQuery.replace("<Identificacion>", strDocumento);
strQuery = strQuery.replace("<transaccion>", strTransaccion);
strQuery = strQuery.replace("<TipoMensaje>", strTipoMensaje);
strQuery = strQuery.replace("<plan>", strplan);

return strQuery;
}	


public ResultSet Ejecutar_Query(String Query) throws SQLException {
	Sql_Execute DAO = new Sql_Execute();
	ResultSet rs = DAO.sql_Execute(Query);
	return rs;
}

public ResultSet Ejecutar_Query_Oracle(String Query) throws SQLException {
	Sql_Execute_Oracle DAO = new Sql_Execute_Oracle();
	ResultSet rs = DAO.sql_Execute(Query);
	return rs;
}

public void Verificar_Consulta_COMFFLGBVL(ResultSet rs, List<List<String>> data ) throws SQLException, FileNotFoundException {
	 List<StringBuilder> lista = new ArrayList<StringBuilder>();
	 
   while (rs.next()) {
	   StringBuilder resultado = new StringBuilder();
	   String CodigoRespuesta_Recibido = rs.getString(5);
	   String CodigoRespuesta_Esperada  = data.get(0).get(4);
	 
	   if (CodigoRespuesta_Recibido.trim().equals(CodigoRespuesta_Esperada) ) {
	   for (int i = 1; i <= 32; i ++) {
	   resultado.append(rs.getString(i));
	   resultado.append(";");	   
	    }
	   String Documento_Recibido = rs.getString(1);	
	   String Documento_Esperado = data.get(0).get(0);
	   assertThat(Documento_Recibido, equalTo(Documento_Esperado));
	   String Transaccion_Recibido = rs.getString(4);
	   String Transaccion_Esperada  = data.get(0).get(3);
	   assertThat(Transaccion_Recibido, equalTo(Transaccion_Esperada));   	 
	   CodigoRespuesta_Recibido = rs.getString(5);
       CodigoRespuesta_Esperada  = data.get(0).get(4);
	   assertThat(CodigoRespuesta_Recibido, equalTo(CodigoRespuesta_Esperada));   	 
	   String Oficina_Origen_Recibido = rs.getString(6);
	   //String Oficina_Origen_Esperado = data.get(0).get(5);
	   //assertThat(Oficina_Origen_Recibido, equalTo(Oficina_Origen_Esperado));
	   String Plan_Recibido = rs.getString(8);
	   String Plan_Esperado = data.get(0).get(7);
	   assertThat(Plan_Recibido, equalTo(Plan_Esperado));
	   String Oficial_Original_Recibido = rs.getString(9);
	   String Oficial_Original_Esperado = data.get(0).get(8);   
	   assertThat(Oficial_Original_Recibido, equalTo(Oficial_Original_Esperado));
	   String Codigo_BaseAnual_Recibido = rs.getString(12);
	   String Codigo_BaseAnual_Esperado = data.get(0).get(11);
	   assertThat(Codigo_BaseAnual_Recibido, equalTo(Codigo_BaseAnual_Esperado));
	   String Codigo_frecuencia_pago_Recibido = rs.getString(13);
	   String Codigo_frecuencia_pago_Esperado = data.get(0).get(12);
	   assertThat(Codigo_frecuencia_pago_Recibido, equalTo(Codigo_frecuencia_pago_Esperado));   
	   String Garantia_Recibido = rs.getString(14);
	   String Garantia_Esperado =  data.get(0).get(13);
	   assertThat(Garantia_Recibido, equalTo(Garantia_Esperado));  	
	   String Estado_Prestamo_Recibido = rs.getString(15);
	   String Estado_Prestamo_Esperado = data.get(0).get(14);
	   assertThat(Estado_Prestamo_Recibido, equalTo(Estado_Prestamo_Esperado)); 
	   String Codigo_Pago_Automatico_Recibido = rs.getString(22);
//	   String Codigo_Pago_Automatico_Esperado = data.get(0).get(21);	
//	   assertThat(Codigo_Pago_Automatico_Recibido, equalTo(Codigo_Pago_Automatico_Esperado));  
	   String Canal_Origen_Recibido = rs.getString(26);
	   String Canal_Origen_Esperado = data.get(0).get(25);
	   assertThat(Canal_Origen_Recibido, equalTo(Canal_Origen_Esperado));  
	   String Tipo_Mensaje_recibido = rs.getString(27);
	   String Tipo_Mensaje_Esperado = data.get(0).get(26);
	   assertThat(Tipo_Mensaje_recibido, equalTo(Tipo_Mensaje_Esperado));   
	   
	   strPrestamo =  rs.getString(7);
	   String value = rs.getString(25);
	   Monto_contrato =Integer.parseInt(rs.getString(25));
	   strCodigoDes = rs.getString(10);
	   strCodigoDeb = rs.getString(11);
	   strPlazo = rs.getString(16);
	   strTasa= rs.getString(17);
	   strTasa.substring(2, 7);
	   strTasaSV = rs.getString(18);
	   strFechaDes = rs.getString(19) ;
	   strFechaV = rs.getString(20);
	   strNroCuentaDes = rs.getString(21);
	   strNroCuentaDeb = rs.getString(23);
	   strValorCuota = rs.getString(24);
	   strNroCaso = rs.getString(28);
	   intNroSec = Integer.parseInt(rs.getString(31));
	   
	   }else {  
		   
		   for (int i = 1; i <= 31; i ++) {
			   resultado.append(rs.getString(i));
			   resultado.append(";");	   
			}   
		   
	     }
	   lista.add(resultado);
	   }
   
   try { 
   FileOutputStream file = new FileOutputStream("C:\\Users\\UserQV\\Documents\\Archivos_Automatizaciones\\COMFFLGBVL.csv");
  for (StringBuilder stringBuilder : lista) {
	
		file.write(stringBuilder.toString().getBytes());
		file.write("\t\r".getBytes());
	
    }
  
 
		file.close();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
   }


//Verificr maestro de prestamos
public String Armar_Query_Consulta_LMBAL(String strDocumento) {
	String strQuery= "SELECT LMNOOB,LMNOAC,LMCDPL,LMOOFF,LMCDPD,LMCDRD,LMCDYB,LMCDPF,LMCDST,LMNOTP,LMRTNM,LMRTI1,LMDTNT,LMDTMT,LMDPAC,"
			+ "LMRPAC, LMAMRP,LMAMTC,LMCDUA, LMDSU1,LMOFU1, LMNOCF FROM VISIONR.LMBAL WHERE LMNOAC = "  + strPrestamo;
	strQuery= strQuery.replace("Identificacion", strDocumento);
	return strQuery;
}
public void Verificar_Consulta_LMBAL(ResultSet rs, List<List<String>> data) throws SQLException {
	List<StringBuilder> lista = new ArrayList<StringBuilder>();
	while(rs.next()) {
		   StringBuilder resultado = new StringBuilder();
		
		   String CodigoRespuesta_Esperada  = data.get(0).get(4);   
		  
		   if (CodigoRespuesta_Esperada.equals("9999")) {
		   for (int i = 1; i <= 2; i ++) {
		   resultado.append(rs.getString(i));
		   resultado.append(";");	   
		    }	   
		   }else {    
			   for (int i = 1; i <= 22; i ++) {
				   resultado.append(rs.getString(i));
				   resultado.append(";");	 				   
				}
		   
		String OficinaOrigen_Recibido = rs.getString(1).trim();
		//String OficinaOrigen__Esperado = data.get(0).get(5);
		//assertThat(OficinaOrigen_Recibido.trim(), equalTo(OficinaOrigen__Esperado.trim()));
		String Prestamo_Recibido = rs.getString(2);
		String Prestamo_Esperado =  strPrestamo;
		assertThat(Prestamo_Recibido, equalTo(Prestamo_Esperado));
		String TipoPlan_Recibido = rs.getString(3);
        String TipoPlan_Esperado  = data.get(0).get(7);
        assertThat(TipoPlan_Recibido, equalTo(TipoPlan_Esperado));
        String OficialOriginal_Recibido = rs.getString(4);
        String OficialOriginal_Esperado = data.get(0).get(8);
        assertThat(OficialOriginal_Recibido.trim(), equalTo(OficialOriginal_Esperado.trim()));
        String CodigoDes_Recibido = rs.getString(5);
        String CodigoDes_Esperado = strCodigoDes;
        assertThat(CodigoDes_Recibido.trim(), equalTo(CodigoDes_Esperado));
        String CodigoDeb_Recibido = rs.getString(6);
        String CodigoDeb_Esperado = strCodigoDeb;
        assertThat(CodigoDeb_Recibido.trim(), equalTo(CodigoDeb_Esperado));
        String CodigoBase_Recibido = rs.getString(7);
        String CodigoBase_Esperado = data.get(0).get(11);
        assertThat(CodigoBase_Recibido.trim(), equalTo(CodigoBase_Esperado.trim()));
        String CodigoFrecuencia_Recibido = rs.getString(8);
        String CodigoFrecuencia_Esperado = data.get(0).get(12);
        assertThat(CodigoBase_Recibido.trim(), equalTo(CodigoBase_Esperado.trim()));
        String Estado_Prestamo_Recibido = rs.getString(9);
        String Estado_Prestamo_Esperado = data.get(0).get(14);
        assertThat(Estado_Prestamo_Recibido.trim(), equalTo(Estado_Prestamo_Esperado.trim()));
        String Plazo_Recibido = rs.getString(10);
        String Plazo_Esperado = strPlazo;
        assertThat(Plazo_Recibido.trim(), equalTo(Plazo_Esperado));
        String Tasa_Recibida = rs.getString(11).substring(2, 8);
        String Tasa_Esperada = strTasa.substring(1, 7);
        assertThat(Tasa_Recibida.trim(), equalTo(Tasa_Esperada.trim()));
        String TasaSV_Recibida = rs.getString(12).substring(2, 11);
        String TasaSV_Esperada = strTasaSV.substring(1, 10);
        assertThat(TasaSV_Recibida.trim(), equalTo(TasaSV_Esperada.trim()));
        String FechaDes_Recibida = rs.getString(13);
        String FechaDes_Esperada = strFechaDes;
        assertThat(FechaDes_Recibida.trim(), equalTo(FechaDes_Esperada.trim()));
        String FechaV_Recibida = rs.getString(14);
        String FechaV_Esperada = strFechaV;
        assertThat(FechaV_Recibida.trim(), equalTo(FechaV_Esperada.trim()));
        String NroCuentaDes_Recibida = rs.getString(15);
        String NroCuentaDes_Esperada = strNroCuentaDes;
        assertThat(NroCuentaDes_Recibida.trim(), equalTo(NroCuentaDes_Esperada));
        String NroCuentaDeb_Recibida = rs.getString(16);
        String NroCuentaDeb_Esperada = strNroCuentaDeb;
        assertThat(NroCuentaDeb_Recibida.trim(), equalTo(NroCuentaDeb_Esperada));
        double ValorCuota_Recibido = Double.parseDouble(rs.getString(17));
        double ValorCuota_Esperado = Double.parseDouble(strValorCuota.substring(0,strValorCuota.length()-2));
        assertThat(ValorCuota_Recibido, equalTo(ValorCuota_Esperado));
        double MontoTotal_Recibido = Double.parseDouble(rs.getString(18));
        double MontoTotal_Esperado = Double.parseDouble(strMontoTotal.substring(0,strMontoTotal.length()-2));
        assertThat(MontoTotal_Recibido, equalTo(MontoTotal_Esperado));
        String NroCaso_Recibido = rs.getString(20);
        String NroCaso_Esperado = strNroCaso;
        assertThat(NroCaso_Recibido.trim(), equalTo(NroCaso_Esperado.trim()));
        String Oficial_Recibido = rs.getString(21);
        String Oficial_Esperado = data.get(0).get(8);
        assertThat(Oficial_Recibido.trim(), equalTo(Oficial_Esperado.trim()));
        int NroSecuencia_Recibido = Integer.parseInt(rs.getString(22));
        int NroSecuencia_Esperado = intNroSec;
        assertThat(NroSecuencia_Recibido, equalTo(NroSecuencia_Esperado));	        
	}
		   lista.add(resultado);

		   try { 
			   FileOutputStream file = new FileOutputStream("C:\\Users\\UserQV\\Documents\\Archivos_Automatizaciones\\LMBAL.csv");
			  for (StringBuilder stringBuilder : lista) {
				
					file.write(stringBuilder.toString().getBytes());
					file.write("\t\r".getBytes());
				
			    }
			  
			 
					file.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				
             }
	
	     }
	}

public String Consulta_CNAME(String strDocumento) {
	
String strQuery ="SELECT CNNAMK, CNSNAM  FROM VISIONR.CNAME WHERE CNNOSS ='<Identificacion>' ORDER BY CNNAMK";
strQuery = strQuery.replace("<Identificacion>", strDocumento);	
return strQuery;
}

public String Verificar_Consulta_CNAME(ResultSet rs) throws SQLException, IOException {
	XSSFSheet spreadsheet = workbook.createSheet("cname");
	XSSFRow row = spreadsheet.createRow(1);
	XSSFCell cell;
		
	cell = row.createCell(1);
	cell.setCellValue("LLAVE_NOMBRE");
	cell = row.createCell(2);
	cell.setCellValue("NOMBRE");
	int i = 2;
	while (rs.next()) {
	row = spreadsheet.createRow(i);
    cell = row.createCell(1);
	llave_nombre  = rs.getString(1);
	cell.setCellValue(llave_nombre);
	cell = row.createCell(2);
	Nombre = rs.getString(2);
	cell.setCellValue(Nombre);
	 String[] Nombre_parts = Nombre.split(" ");
	 Nombre_corto = Nombre_parts[0]; 
	 i++;
	}
	
	FileOutputStream out = new FileOutputStream(new File("cname.xlsx"));
    workbook.write(out);
    out.close();
    System.out.println("cname.xlsx written successfully");
    return Nombre_corto;
}

public String  Armar_Query_Consulta_XCRL( ) {
	String strQuery ="SELECT XCNAMK, XCNOSQ, XCCDCT, XCCDAC, XCAMAP,XCAMTT, XCAMTD, XCDTLM FROM VISIONR.XCRL WHERE XCNAMK  ='" + llave_nombre + "'AND XCCDCT ='"+ tipo_credito + "'AND XCCDAC ='" + cod_actividad +"'ORDER BY XCNAMK";
	return strQuery;
	
     }

public String Consultar_Clave_Dinamica(String strDocumento) {
	
	String strQuery ="SELECT substr(AENMSGENV, 49, 6) FROM PCCLIBRAMD.PCCFFLGAEN WHERE AENFECHA ='"+ fecha + "'AND AENNROIDE = '<Identificacion>' ORDER BY AENHORA DESC LIMIT 1";
	strQuery = strQuery.replace("<Identificacion>", strDocumento);	
	return strQuery;
		
}

public String Obtener_Clave_Dinamica(ResultSet rs)throws SQLException, FileNotFoundException  {
	while (rs.next()) {
		Clave_dinamica  = rs.getString(1);	
		}
	return Clave_dinamica;
}

public void Verificar_Consulta_XCRL(ResultSet rs)throws SQLException, FileNotFoundException { 
	List<StringBuilder> lista = new ArrayList<StringBuilder>();
	 while (rs.next()) {
		   StringBuilder resultado = new StringBuilder();
				 for (int i = 1; i <= 8; i ++) {
					   resultado.append(rs.getString(i));
					   resultado.append(";");	   
					    }
				 						 		 
				 String[] Nombre_parts =  rs.getString(7).split("\\.");	
				 Monto_retiro_limite = Nombre_parts[0];                
				 Monto_retiro =	Integer.parseInt(Monto_retiro_limite);
				 Monto_total = Monto_retiro + Monto_contrato;
				 
				  lista.add(resultado);
			 }
	 try { 
		   FileOutputStream file = new FileOutputStream("C:\\Users\\UserQV\\Documents\\Archivos_Automatizaciones\\limite.csv");
		  for (StringBuilder stringBuilder : lista) {
			
				file.write(stringBuilder.toString().getBytes());
				file.write("\t\r".getBytes());
			
		    }
			file.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   }

public void Verificar_Consulta_XCRL_Limite(ResultSet rs) throws SQLException, FileNotFoundException{
	List<StringBuilder> lista = new ArrayList<StringBuilder>();
	 while (rs.next()) {
		   StringBuilder resultado = new StringBuilder();
				 for (int i = 1; i <= 8; i ++) {
					   resultado.append(rs.getString(i));
					   resultado.append(";");	   
					    }
							 
				 String[] Nombre_parts =  rs.getString(7).split("\\.");	
				 Monto_retiro_limite = Nombre_parts[0];   
				 Monto_retiro =Integer.parseInt(Monto_retiro_limite);	
				 assertThat(Monto_retiro, equalTo(Monto_total)); 
				 lista.add(resultado);
       }
	 try { 
		   FileOutputStream file = new FileOutputStream("C:\\Users\\UserQV\\Documents\\Archivos_Automatizaciones\\limite2.csv");
		  for (StringBuilder stringBuilder : lista) {
			
				file.write(stringBuilder.toString().getBytes());
				file.write("\t\r".getBytes());
			
		    }
			file.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   }

 public String Consultar_BasePrecalculado(String strDocumento){
	 String strQuery ="SELECT W.NUM_ID,W.COD_PROD,W.PROD,W.RESP_PRECALC,W.ESTADO,W.CUPO,W.GRP_RIESGO  FROM SCHPREAPDB.PRECALCULADO W WHERE W.COD_PROD ='"+ Cod_produc +"' AND W.NUM_ID ='<Identificacion>'";	 
	 strQuery = strQuery.replace("<Identificacion>", strDocumento); 
	 return strQuery;
 }
 
 public String Recorrer_BasePrecalculado(ResultSet rs) throws SQLException, FileNotFoundException{
	 List<StringBuilder> lista = new ArrayList<StringBuilder>();
	 while (rs.next()) {
		   StringBuilder resultado = new StringBuilder();
				 for (int i = 1; i <= 7; i ++) {
					   
					   resultado.append(rs.getString(i));
					   resultado.append(";");	
					   Cupo_Recibido = rs.getString(6); 				   
					    }
				 lista.add(resultado);
	   }
 
 try { 
 FileOutputStream file = new FileOutputStream("C:\\Users\\UserQV\\Documents\\Archivos_Automatizaciones\\precalculado.csv");

for (StringBuilder stringBuilder : lista) {
	
		file.write(stringBuilder.toString().getBytes());
		file.write("\t\r".getBytes());
	
  }
 
	 file.close();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
return Cupo_Recibido;
 }
	 
 
//PCCFFDGAL 
public String Armar_query_Consulta_tel_email(String strDocumento) {
	
	String strQuery ="SELECT ALNROCEL,ALEMAIL FROM PCCLIBRAMD.PCCFFDGAL WHERE ALNROIDE='<Identificacion>'";
	strQuery = strQuery.replace("<Identificacion>", strDocumento);	
	return strQuery;
		
 }

//PCCFFDGAL
public void Consultar_Correo_tel(ResultSet rs) throws SQLException, FileNotFoundException{
	 List<StringBuilder> lista = new ArrayList<StringBuilder>();
	 while (rs.next()) {
		 StringBuilder resultado = new StringBuilder();
		 for (int i = 1; i <= 2; i ++) {
			   
			   resultado.append(rs.getString(i));
			   resultado.append(";");	
			  				   
			    }
		 lista.add(resultado);

	 }
	 try { 
		 FileOutputStream file = new FileOutputStream("C:\\Users\\UserQV\\Documents\\Archivos_Automatizaciones\\correotel.csv");

		for (StringBuilder stringBuilder : lista) {
			
				file.write(stringBuilder.toString().getBytes());
				file.write("\t\r".getBytes());
			
		  }
		 
			 file.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		 }

public void Consultar_cname_unificado(String strDocumento) throws SQLException, IOException{
	String strQuery ="SELECT CNNAMK, CNSNAM  FROM VISIONR.CNAME WHERE CNNOSS ='<Identificacion>' ORDER BY CNNAMK";
	strQuery = strQuery.replace("<Identificacion>", strDocumento);	
	ResultSet rs = Ejecutar_Query(strQuery);
	XSSFSheet spreadsheet = workbook.createSheet("cname");
	XSSFRow row = spreadsheet.createRow(1);
	XSSFCell cell;
		
	cell = row.createCell(1);
	cell.setCellValue("LLAVE_NOMBRE");
	cell = row.createCell(2);
	cell.setCellValue("NOMBRE");
	int i = 2;
	while (rs.next()) {
	row = spreadsheet.createRow(i);
    cell = row.createCell(1);
	llave_nombre  = rs.getString(1);
	cell.setCellValue(llave_nombre);
	cell = row.createCell(2);
	Nombre = rs.getString(2);
	cell.setCellValue(Nombre);
	 String[] Nombre_parts = Nombre.split(" ");
	 Nombre_corto = Nombre_parts[0]; 
	 i++;
	}
	i++;
	FileOutputStream out = new FileOutputStream(new File("cname.xlsx"));
    workbook.write(out);
    out.close();
    System.out.println("cname.xlsx written successfully");
   	
}

}




