package com.bancolombia.preaprobado.libreinversion.utilities;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.bancolombia.preaprobado.libreinversion.utilities.Conection;
public class Sql_Execute_Oracle {
	
	  Conection manager = null;
	
	  /** Creates a new instance of DAOResultSet */
		 public Sql_Execute_Oracle() {
		 manager = Conection.getInstance();
		 }
	
		 public ResultSet sql_Execute (String Query) throws SQLException {
			 manager = Conection.getInstance();
			 Connection con = manager.getConexion();
			 PreparedStatement ps = con.prepareStatement(Query);
			 ResultSet rs = ps.executeQuery();
			 return rs;
			 } 
		 
		 public ResultSet sql_Execute_tasas (String Query) throws SQLException {
			 manager = Conection.getInstance();
			 Connection con = manager.getConexionTasas();
			 PreparedStatement ps = con.prepareStatement(Query);
			 ResultSet rs = ps.executeQuery();
			 return rs;
			 } 
		 
		 public ResultSet sql_Execute_Bizagi (String Query) throws SQLException {
			 manager = Conection.getInstance();
			 Connection con = manager.getConexionBizagi();
			 PreparedStatement ps = con.prepareStatement(Query);
			 ResultSet rs = ps.executeQuery();
			 return rs;
			 } 

}
