package com.bancolombia.preaprobado.libreinversion.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;

public class RequisitosPages extends PageObject {

	@FindBy(className = "img-product")
	private WebElement imgempieza;
	
	@FindBy(id ="pagina0FPLIBotonId")
	private WebElement btnsolicitarcredito;
	
    //Metodo para presionar el boton de solicitar credito
	public void presionarBotonSolicitarCredito() throws Exception {
		
		Thread.sleep(8000);
		JavascriptExecutor executor =(JavascriptExecutor)getDriver();
		executor.executeScript("window.scrollBy(0,400)", "");	
		Thread.sleep(3000);
		imgempieza.click();
		Thread.sleep(10000);
	}
	
}
