package com.bancolombia.preaprobado.libreinversion.pages;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.ibm.icu.impl.Assert;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class OfertaPages extends PageObject {
	
	BackendAs400db2Page backendAs400db2Page;
	
	
	@FindBy(id = "montoSolicitadoLibreInversion")
	private WebElement txtCupoasolicitar;
	
	@FindBy(id ="slctplazoCredito")
    private WebElementFacade listplazo;
	
	@FindBy(id ="calcularCuotaBotonId")
	private WebElement btncalcular;
	
	@FindBy (id ="cuenta")
	private WebElementFacade listdesembolso;
	
	@FindBy (id ="cuentaDebito")
	private WebElementFacade listdebito;
	
	@FindBy (id ="continuarPagina1FPLIBtnId")
	private WebElement btncontinuar;
	
	@FindBy (id ="debitoAutomatico")
	private WebElement radiobutoyes;
	
	@FindBy (id ="noDebitoAutomatico")
	private WebElement radiobutono;
	
	@FindBy (xpath="//*[@id='content']/div/form/div[13]/div[2]/p")
    private WebElement labeldebitoText;
	
	@FindBy (className="mt30.xs-mt20.xs12.ng-binding")
	private WebElement labelNombreText;

    String Numero_cuenta_debito;
    String Nombre_Esperado;
    String Nombre_Recibido;
    String Numero_cuenta_desembolso;

    //Metodo para calcular la cuota de desembolso
	 public void calcularCuota(String Cupo, String Plazo) throws InterruptedException {
		    txtCupoasolicitar.sendKeys(Cupo);
		    listplazo.selectByVisibleText(Plazo);
		    Thread.sleep(2000);
		    btncalcular.click();
		    Thread.sleep(3000);
		    JavascriptExecutor executor =(JavascriptExecutor)getDriver();
			executor.executeScript("window.scrollBy(0,300)", "");	
			Thread.sleep(3000);
	    } 
	 
	 
	//Metodo para comparar el nombre del cliente en el fron vs el que se encuentra en el cname  
	 public void obtenerNombreclienteoferta(String strDocumento)throws  InterruptedException, SQLException, IOException {
		   String Nombre = labelNombreText.getText();
		   String[] Nombre_parts = Nombre.split(",");
		   Nombre_Esperado = Nombre_parts[0];
		   String query =backendAs400db2Page.Consulta_CNAME(strDocumento);
		   ResultSet rs = backendAs400db2Page.Ejecutar_Query(query);
		   Nombre_Recibido =(backendAs400db2Page.Verificar_Consulta_CNAME(rs));
		   if (Nombre_Esperado.equalsIgnoreCase(Nombre_Recibido)) {
			   System.out.println("Nombre correcto");
			}	
	   }
	 
	
	 //Metodo para seleccionar el nùmero de cuenta
	 public void seleccionarNumerodeCuenta(String Desembolso) throws InterruptedException {
		   listdesembolso.selectByVisibleText(Desembolso);
		   Numero_cuenta_desembolso = Desembolso;
    	    Thread.sleep(3000);
		   
	    } 
	 
	 //Metodo para Usar servicio automatico
	 public void usarServicioAutomatico(String Desicion, String Debito)throws InterruptedException {
		 if (Desicion.equals("si")) {
			 evaluateJavascript("arguments[0].click();",getDriver().findElement(By.id("debitoAutomatico")));
//			 Thread.sleep(3000);
			 Numero_cuenta_debito =labeldebitoText.getText();		 
//			 listdebito.selectByVisibleText(Debito);
			 assertThat(Numero_cuenta_debito, equalTo(Numero_cuenta_desembolso)); 
		     btncontinuar.click();
		   
		     
		 }else if(Desicion.equals("no")) {
			 //JavascriptExecutor executor =(JavascriptExecutor)getDriver();
			 evaluateJavascript("arguments[0].click();",getDriver().findElement(By.id("noDebitoAutomatico")));
			 Thread.sleep(3000);
			 btncontinuar.click();
		 }
		 
		 Thread.sleep(30000);
	   }	 
}
