package com.bancolombia.preaprobado.libreinversion.definitions;

import com.bancolombia.preaprobado.libreinversion.steps.AutenticaSteps;
import com.bancolombia.preaprobado.libreinversion.steps.BackendAs400db2Steps;

import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Steps;

public class BackiendAs400DB2ClaveDefinitions {

	@Steps
	//AutenticaSteps AutenticaSteps;
	BackendAs400db2Steps BackSteps;
	
	@Given("^valido los datos del iseries (\\d+)$")
	public void valido_los_datos_del_iseries(String strDocumento) throws Exception {
	    
		BackSteps.Consultar_clavedinamica(strDocumento);
	}
	
}
