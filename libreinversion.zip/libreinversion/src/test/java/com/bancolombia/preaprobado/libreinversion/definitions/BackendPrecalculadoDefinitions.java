package com.bancolombia.preaprobado.libreinversion.definitions;

import com.bancolombia.preaprobado.libreinversion.steps.BackendAs400db2Steps;

import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Steps;

public class BackendPrecalculadoDefinitions {
	
	@Steps
	BackendAs400db2Steps BackendAs400db2Steps;
	
	@Given("^valido los datos del precalculado (\\d+)$")
	public void valido_los_datos_del_precalculado(String strDocumento) throws Exception {
		BackendAs400db2Steps.Armar_Query_Consulta_Precalculado(strDocumento);
	  
	}


}
