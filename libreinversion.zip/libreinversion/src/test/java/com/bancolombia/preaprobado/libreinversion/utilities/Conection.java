package com.bancolombia.preaprobado.libreinversion.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import javax.swing.JOptionPane;

public class Conection {
	
	     private static Conection instance;
		 private String user;
		 private String password; 
		 private String name_host;
		 private String puerto;
		 private String sid;
		 private String user_tasas;
		 private String password_tasas; 
		 private String name_host_tasas;
		 private String puerto_tasas;
		 private String sid_tasas;
		 private String user_bizagi;
		 private String password_bizagi; 
		 private String name_host_bizagi;
		 private String puerto_bizagi;
		 private String sid_bizagi;
		 
//		 cb.driver=oracle.jdbc.driver.OracleDriver
		 private Conection() {
			 inicialice();
			 } 		 
		 
	private void inicialice() {
			try {
				 Properties prop = new Properties();
				 prop.load(new FileReader("C:\\Workspace2\\libreinversion\\dbConfig.properties"));
				 //Propiedades precalculado
				 this.user = prop.getProperty("cb.user");
				 this.password = prop.getProperty("cb.password");
				 this.name_host = prop.getProperty("cb.name_host");
				 this.puerto = prop.getProperty("cb.puerto");
				 this.sid = prop.getProperty("cb.sid");
				//Propiedades Tasas
				 this.user_tasas = prop.getProperty("tb.user");
				 this.password_tasas = prop.getProperty("tb.password");
				 this.name_host_tasas = prop.getProperty("tb.name_host");
				 this.puerto_tasas = prop.getProperty("tb.puerto");
				 this.sid_tasas = prop.getProperty("tb.sid");
				 //Propiedades Bizagi
				 this.user_bizagi = prop.getProperty("bb.user");
				 this.password_bizagi = prop.getProperty("bb.password");
				 this.name_host_bizagi = prop.getProperty("bb.name_host");
				 this.puerto_bizagi = prop.getProperty("bb.puerto");
				 this.sid_bizagi = prop.getProperty("bb.sid");
				 
				 Class.forName(prop.getProperty("cb.driver"));
				
			} catch (IOException e) {
				 e.printStackTrace();
			} catch (ClassNotFoundException e) {
				 // TODO Auto-generated catch block
				 e.printStackTrace();
			}
			
		}
	    //aplicando Singleton
	      public static Conection getInstance() {
	      if (instance == null)
	          instance = new Conection();
	           return instance;
	        }
       
     //Conexion precalculado
	 public Connection getConexion() throws SQLException {
		 Connection con = DriverManager.getConnection(this.name_host,this.user, this.password);
		 //JOptionPane.showInputDialog(con);
		 return con;
		 }
	 //Conexion Tasas
	 public Connection getConexionTasas() throws SQLException{
		 Connection con = DriverManager.getConnection(this.name_host_tasas, this.user_tasas, this.password_tasas);		 
		return con;
		 
	 }
	 //Conexion Bizagi
	 public Connection getConexionBizagi() throws SQLException{
		 Connection con = DriverManager.getConnection(this.name_host_bizagi, this.user_bizagi, this.password_bizagi);	 
		return con;
		 
	 }
	 

		
}

	
	

