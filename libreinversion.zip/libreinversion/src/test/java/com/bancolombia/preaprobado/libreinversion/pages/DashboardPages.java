package com.bancolombia.preaprobado.libreinversion.pages;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.headius.invokebinder.transform.Convert;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;

public class DashboardPages extends PageObject{
	
   BackendAs400db2Page backendAs400db2Page;
	
   @FindBy(xpath ="//div[@class='col-xs-12 col-sm-8 col-md-8 mt40']")
   private WebElement lbltextLib;
 
   @FindBy(xpath = "//*[@id='divListaPreabprobados']/div[5]/div[1]/span[2]")
   private WebElement lbltextmonto;
   
   @FindBy(id ="preAprobadoBotonlibre inversion")
   private WebElement btnSolicitaloaqui;
   
   @FindBy (xpath="//*[@id='content']/div/div[1]/div[1]/h1")
   private WebElement labelNombreText;
   
   @FindBy (xpath ="//span[@class='pull-right.linkProduct.blue.item-value.ng-binding']")
   private WebElement lblvaluecupopreaprobado;
   
   @FindBy (xpath ="//span[@class='linkProduct2 blue ng-binding']")
   private 	WebElement lblnameproductpreaprobado;
    
   String Nombre_Esperado;
   String Nombre_Recibido;
   String prod;
   int valor1;
   int valor2;
   String valor3;
   String Cupo_Esperado;
   String Cupo_Recibido;
  
   //Metodo para comparar el cupo  desde el front vs la base de datos precalculado 
   public void compararCupoprecalculado(String strDocumento)throws Exception {
	   List<WebElement> myElements = getDriver().findElements(By.xpath("//span[@class='linkProduct2 blue ng-binding']"));
	   List<WebElement> myElements2 = getDriver().findElements(By.xpath("//span[@class='pull-right linkProduct blue item-value ng-binding']"));
	   
	   for(int i = 0; i< myElements.size(); i++){ //Itera elementos del primer ArrayList
		   //System.out.println(myElements.get(i).getText());
		    for(int j = 0; j< myElements2.size(); j++){	 
		    	if(myElements.get(i).getText().equals("Libre Inversión")){	    		
		    		Cupo_Esperado = myElements2.get(i).getText().replace(",", "").substring(1);
		    		
		    	}
		    	
		    }
	   }
	   
	   String query=backendAs400db2Page.Consultar_BasePrecalculado(strDocumento);
	   ResultSet rs=backendAs400db2Page.Ejecutar_Query_Oracle(query);
	   valor3 =backendAs400db2Page.Recorrer_BasePrecalculado(rs);
	   valor1 = Integer.parseInt(valor3);
	   valor2 = (Math.round(valor1));
	   Cupo_Recibido =Integer.toString(valor2);   
	   assertThat(Cupo_Recibido, equalTo(Cupo_Esperado)); 
	   System.out.println(Cupo_Recibido + "" + Cupo_Esperado);
	   
   }
   
   
 //Metodo para comparar el nombre del cliente en el fron vs el que se encuentra en el cname  
   public void obtenerNombrecliente(String strDocumento)throws  InterruptedException, SQLException, IOException {
	   Nombre_Esperado = labelNombreText.getText().substring(11);
	   String query =backendAs400db2Page.Consulta_CNAME(strDocumento);
	   ResultSet rs = backendAs400db2Page.Ejecutar_Query(query);
	   Nombre_Recibido =(backendAs400db2Page.Verificar_Consulta_CNAME(rs));
	   
	   if (Nombre_Esperado.equalsIgnoreCase(Nombre_Recibido)) {
		   System.out.println("Nombre correcto");
		}	   
	  
   }
   
   
   //Metodo  para presionar el boton de solicitar credito de libre inversiòn
	public void presionarBotonSolicitar() throws Exception {
		Thread.sleep(2000);
		JavascriptExecutor executor =(JavascriptExecutor)getDriver();
		executor.executeScript("window.scrollBy(0,350)", "");		
		btnSolicitaloaqui.click();
		
	}
}
