//package com.bancolombia.preaprobado.libreinversion.utilities;
//
//public class Enmascarar {
//	
//	public static String enmascarar(String texto){ 
//
//		String textoAux = texto;
//		String ARROBA="@";
//		String CERO="0";
//		String CADENA_VACIA;
//		
//		if (texto.contains(ARROBA)) {
//			texto = texto.split(ARROBA)[ConstanteNumerico.CERO.getValor()];
//		}
//		
//		int mitad = texto.length() / ConstanteNumerico.DOS.getValor();
//		double porcentage = texto.length() * 0.3;
//		double mitadSubcadena = porcentage / ConstanteNumerico.DOS.getValor();
//		
//		int rangoInicio = (int) (mitad - mitadSubcadena);
//		int rangoFinal = (int) (mitad + mitadSubcadena);
//		
//		String subText = texto.substring(rangoInicio, rangoFinal);
//		String cadenaEnmascaramiento = ConstanteGeneral.CADENA_VACIA.getValor();
//		
//		for (int i = 0; i < subText.length(); i++) {
//			
//			cadenaEnmascaramiento += ConstanteGeneral.ASTERISCO.getValor();
//		}
//		
//		String textoFinal = ConstanteGeneral.CADENA_VACIA.getValor();
//		
//		if ((textoAux.contains(ConstanteGeneral.ARROBA.getValor()))) {
//			
//			textoFinal = textoAux.replace(subText, cadenaEnmascaramiento);
//		} else {
//			textoFinal = texto.replace(subText, cadenaEnmascaramiento);
//		}
//		
//		
//		return textoFinal;
//	}
//
//}
