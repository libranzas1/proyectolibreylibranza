package com.bancolombia.preaprobado.models;

public class Tipos {
	
	private String  Type;
	private Object value;
	private TiposDatos tipo;
	private int indicador;
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
	public Object getValue() {
		return value;
	}
	public void setValue(Object value) {
		this.value = value;
	}
	public TiposDatos getTipo() {
		return tipo;
	}
	public void setTipo(TiposDatos tipo) {
		this.tipo = tipo;
	}
	public int getIndicador() {
		return indicador;
	}
	public void setIndicador(int indicador) {
		this.indicador = indicador;
	}
	public Tipos(String type, Object value, TiposDatos tipo, int indicador) {
		Type = type;
		this.value = value;
		this.tipo = tipo;
		this.indicador = indicador;
	}
	
}
