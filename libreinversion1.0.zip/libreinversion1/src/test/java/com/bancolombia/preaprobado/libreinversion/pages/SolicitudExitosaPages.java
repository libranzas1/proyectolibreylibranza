package com.bancolombia.preaprobado.libreinversion.pages;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;

public class SolicitudExitosaPages extends PageObject {
	
	@FindBy(xpath = "//*[@id=\"content\"]/div[2]/div[2]/div/button")
	private WebElement btncerrar;

	
	public void finalizarcontenido()throws  InterruptedException {
		//Thread.sleep(30000);
		btncerrar.click();
	}
	
}
