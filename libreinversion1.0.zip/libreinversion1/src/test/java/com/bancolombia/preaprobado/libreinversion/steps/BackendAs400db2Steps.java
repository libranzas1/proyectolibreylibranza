package com.bancolombia.preaprobado.libreinversion.steps;

import java.sql.ResultSet;
import java.util.List;
import  com.bancolombia.preaprobado.libreinversion.pages.BackendAs400db2Page;

import jnr.ffi.Struct.int32_t;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;

public class BackendAs400db2Steps extends ScenarioSteps {
	
	BackendAs400db2Page  BackendAs400db2Page;

	@Step
	public void Consultar_COMFFLGBV(List<List<String>> data) throws Exception {
	
		String strDocumento = data.get(0).get(0);			
		String strTransaccion = data.get(0).get(3);
		String strTipoMensaje = data.get(0).get(26);		
		String query = BackendAs400db2Page.Armar_Query_Consulta_COMFFLGBVL(strDocumento,strTransaccion,strTipoMensaje);
	    ResultSet rs = BackendAs400db2Page.Ejecutar_Query(query);
	    
	    BackendAs400db2Page.Verificar_Consulta_COMFFLGBVL(rs, data);
	}
	
	
	@Step
	 public void Consultar_LMBAL(List<List<String>> data) throws Exception {
  	  String strDocumento = data.get(0).get(0);
        String query = BackendAs400db2Page.Armar_Query_Consulta_LMBAL(strDocumento);
        ResultSet rs = BackendAs400db2Page.Ejecutar_Query(query);
        BackendAs400db2Page.Verificar_Consulta_LMBAL(rs, data);
  }
	
	
	
	@Step	
	public void Consulta_CNAME(String strDocumento) throws Exception {
		try {
			String query = BackendAs400db2Page.Consulta_CNAME(strDocumento);
			ResultSet rs = BackendAs400db2Page.Ejecutar_Query(query);	
			BackendAs400db2Page.Verificar_Consulta_CNAME(rs);			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Step
	public void  Armar_Query_Consulta_XCRL() throws Exception {
		try {
			String query = BackendAs400db2Page.Armar_Query_Consulta_XCRL();
			ResultSet rs = BackendAs400db2Page.Ejecutar_Query(query);	
			BackendAs400db2Page.Verificar_Consulta_XCRL(rs);			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Step
	public void  Armar_Query_Consulta_XCRL_limite() throws Exception {
		try {
			String query = BackendAs400db2Page.Armar_Query_Consulta_XCRL();
			ResultSet rs = BackendAs400db2Page.Ejecutar_Query(query);	
			BackendAs400db2Page.Verificar_Consulta_XCRL_Limite(rs);			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Step
	public void Consultar_clavedinamica(String strDocumento) throws Exception {
		try {
			String query = BackendAs400db2Page.Consultar_Clave_Dinamica(strDocumento);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
		
}
