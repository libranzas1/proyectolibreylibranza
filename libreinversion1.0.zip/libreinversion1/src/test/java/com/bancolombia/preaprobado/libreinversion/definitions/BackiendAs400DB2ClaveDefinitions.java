package com.bancolombia.preaprobado.libreinversion.definitions;

import com.bancolombia.preaprobado.libreinversion.steps.AutenticaSteps;

import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Steps;

public class BackiendAs400DB2ClaveDefinitions {

	@Steps
	AutenticaSteps AutenticaSteps;
	
	@Given("^valido los datos del iseries (\\d+)$")
	public void valido_los_datos_del_iseries(String strDocumento) throws Exception {
	    
		AutenticaSteps.Consulta_Clave_Dinamica(strDocumento);
	}
	
}
