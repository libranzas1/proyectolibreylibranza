package com.bancolombia.preaprobado.models;

public class TiposDatos {
	  enum tipos{
	String, Date, dooble;
	  }

}
