package com.bancolombia.preaprobado.libreinversion.pages;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;

public class EncuestaPages extends PageObject  {

	//Califica tu experiencia
	@FindBy(xpath = "//*[@id=\"preLibreInversion\"]/div/div/div/form/div/div/div[1]/div[2]/label[5]")
	private WebElement btnexperien1;
	
	@FindBy(xpath = "//*[@id=\"preLibreInversion\"]/div/div/div/form/div/div/div[1]/div[2]/label[4]")
	private WebElement btnexperien2;
	
	@FindBy(xpath = "//*[@id=\"preLibreInversion\"]/div/div/div/form/div/div/div[1]/div[2]/label[3]")
	private WebElement btnexperien3;
	
	@FindBy(xpath = "//*[@id=\"preLibreInversion\"]/div/div/div/form/div/div/div[1]/div[2]/label[2]")
	private WebElement btnexperien4;
	
	@FindBy(xpath = "//*[@id=\"preLibreInversion\"]/div/div/div/form/div/div/div[1]/div[2]/label[1]")
	private WebElement btnexperien5;
	
	//Que fue lo que mas te gusto
	
	@FindBy(xpath = "//*[@id=\"preLibreInversion\"]/div/div/div/form/div/div/div[2]/div/div[2]/div[1]/label")
	private WebElement btnfacilidad;
	
	@FindBy(xpath = "//*[@id=\"preLibreInversion\"]/div/div/div/form/div/div/div[2]/div/div[2]/div[2]/label")
	private WebElement btnagilidad;
	
	@FindBy(xpath = "//*[@id=\"preLibreInversion\"]/div/div/div/form/div/div/div[2]/div/div[2]/div[3]/label")
	private WebElement btnclaridad;
	
	@FindBy(xpath = "//*[@id=\"preLibreInversion\"]/div/div/div/form/div/div/div[2]/div/div[2]/div[4]/label")
	private WebElement btncomodidad;
	
	//Compartenos algo
	
	@FindBy(id ="message-text")
	private WebElement txtmensaje;
	
	//Recomendarias a bancolombia
	@FindBy(id ="ex1Slider")
	private WebElement Exx1Slider;
	
	//Enviar
	@FindBy(id ="finalizarBtnId")
	private WebElement btnfinalizar;
	
	
	public void calificatuexperiencia() throws  InterruptedException {
		btnexperien5.click();
		Thread.sleep(3000);
		btnfacilidad.click();
		Thread.sleep(1000);
		btnclaridad.click();
		Thread.sleep(2000);
		txtmensaje.sendKeys("Excelente la experiencia");
		Thread.sleep(4000);
		btnfinalizar.click();
	}
	
	
	
	
	
	
}

