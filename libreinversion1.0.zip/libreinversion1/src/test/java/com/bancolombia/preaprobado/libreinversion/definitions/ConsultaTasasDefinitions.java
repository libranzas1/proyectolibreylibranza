package com.bancolombia.preaprobado.libreinversion.definitions;

import java.sql.SQLException;

import com.bancolombia.preaprobado.libreinversion.steps.AutenticaSteps;
import com.bancolombia.preaprobado.libreinversion.utilities.ConexionOracle;
import com.bancolombia.preaprobado.models.CredencialesTasasOracle;
import com.bancolombia.preaprobado.models.TasasLibreInversion;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class ConsultaTasasDefinitions {
	@Steps
	AutenticaSteps autenticaSteps;
	
	private String segmento,grupoRiesgo,plan;
	private int plazo, monto;
	
	@Given("^que Yulieth esta en la pantalla del oferta con las caracteristicas (.*) (.*) (.*)$")
	public void queYuliethEstaEnLaPantallaDelOfertaConLasCaracteristicasSGP(String segmento, String grupoRiesgo, String plan) {
	  this.segmento=segmento;
	  this.grupoRiesgo=grupoRiesgo;
	  this.plan=plan;
	  
	}



	@When("^ella calcula su cuota con el \"([^\"]*)\" y el \"([^\"]*)\"$")
	public void ellaCalculaSuCuotaConElYEl(String plazo, String monto) {
	    this.plazo=Integer.parseInt(plazo);
	    this.monto=Integer.parseInt(monto);
	    
	}

	@Then("^ella podra ver la tasa en pantalla igual a la base de datos$")
	public void ellaPodraVerLaTasaEnPantallaIgualALaBaseDeDatos() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
		autenticaSteps.validarTasas(TasasLibreInversion.consultar(ConexionOracle.deTasas(CredencialesTasasOracle.delProperties().getUser(), CredencialesTasasOracle.delProperties().getPass()).
				llamadoAlProcedimiento("BIZ", plan, segmento, grupoRiesgo, monto, plazo), plazo, monto));
	    
	}
}
