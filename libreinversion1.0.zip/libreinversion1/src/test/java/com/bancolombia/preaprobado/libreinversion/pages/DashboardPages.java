package com.bancolombia.preaprobado.libreinversion.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;

public class DashboardPages extends PageObject{
	
   @FindBy(xpath ="//div[@class='col-xs-12 col-sm-8 col-md-8 mt40']/span[@class='linkProduct2 blue ng-binding']")
   private WebElement lbltextLib;
	//JavascriptExecutor executor =(JavascriptExecutor)getDriver();
   @FindBy(xpath = "//*[@id='divListaPreabprobados']/div[5]/div[1]/span[2]")
   private WebElement lbltextmonto;
   
   @FindBy(id ="preAprobadoBotonLIBRE INVERSIÓN")
   private WebElement btnSolicitaloaqui;
   
   @FindBy (className=".m0000.xs-text-center.ng-binding")
   private WebElement labelNombreText;
	
   String Nombre;
   
   public void compararNombrecliente()throws Exception {
	   Nombre = labelNombreText.getText();
	   
   }
   
   
	public void presionarBotonSolicitar() throws Exception {
		List<String>CountryList=new ArrayList<String>();
		String producto = new String();
		producto = lbltextLib.getText().toString();
		
		Thread.sleep(4000);
		JavascriptExecutor executor =(JavascriptExecutor)getDriver();
		executor.executeScript("window.scrollBy(0,350)", "");		
		btnSolicitaloaqui.click();
		
	}
}
