package com.bancolombia.preaprobado.models;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TasasLibreInversion {
	private double tasaMesVencida, tasaNominalAnualMV, tasaEfectivaAnual,tasaMora;

	
	public double getTasaMesVencida() {
		return tasaMesVencida;
	}
	public void setTasaMesVencida(double tasaMesVencida) {
		this.tasaMesVencida = tasaMesVencida;
	}

	public double getTasaNominalAnualMV() {
		return tasaNominalAnualMV;
	}
	public void setTasaNominalAnualMV(double tasaNominalAnualMV) {
		this.tasaNominalAnualMV = tasaNominalAnualMV;
	}

	public double getTasaEfectivaAnual() {
		return tasaEfectivaAnual;
	}
	public void setTasaEfectivaAnual(double tasaEfectivaAnual) {
		this.tasaEfectivaAnual = tasaEfectivaAnual;
	}
	
	public double getTasaMora() {
		return tasaMora;
	}
	public void setTasaMora(double tasaMora) {
		this.tasaMora = tasaMora;
	}

	public TasasLibreInversion(ResultSet rs, int plazoHasta, int montoDesembolsado) throws SQLException {
		while (rs.next()) {

			if (rs.getInt(3) == plazoHasta && montoDesembolsado >= rs.getInt(4) && montoDesembolsado <= rs.getInt(5)) {
				
				this.tasaMesVencida=rs.getDouble(6);
				this.tasaNominalAnualMV=rs.getDouble(7);
				this.tasaEfectivaAnual=rs.getDouble(8);
				this.tasaMora=rs.getDouble(1);
			}

		}

	}
	
	public static TasasLibreInversion consultar(ResultSet rs, int plazoHasta, int montoDesembolsado) throws SQLException {
		return new TasasLibreInversion(rs, plazoHasta, montoDesembolsado);
	}
}
