package com.bancolombia.preaprobado.models;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class CredencialesTasasOracle {

	private String user,pass;

	public CredencialesTasasOracle(String user, String pass) {
		this.user = user;
		this.pass = pass;
	}
	
	public static CredencialesTasasOracle delProperties() {
		Properties prop = new Properties();
		try {
			prop.load(new FileReader("C:\\Workspace2\\libreinversion\\dbConfig.properties"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Propiedades Precalculado
		return new CredencialesTasasOracle(prop.getProperty("tb.user"),prop.getProperty("tb.password"));
	}

	public String getUser() {
		return user;
	}

	public String getPass() {
		return pass;
	}
	
	
}
