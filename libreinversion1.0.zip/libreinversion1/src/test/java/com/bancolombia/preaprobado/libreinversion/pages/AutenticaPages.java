package com.bancolombia.preaprobado.libreinversion.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.annotations.WhenPageOpens;

//@DefaultUrl("https://www.grupobancolombia.com/wps/portal/personas/portal-solicitud-de-productos/")
//@DefaultUrl("http://localhost:9080/bancolombia.dtd.vd.ventasDigitales/inicio.html")
@DefaultUrl("https://169.53.240.205/ventas-digitales/autenticacion")
public class AutenticaPages extends PageObject {

	
	//Validar val = new Validar();
	@FindBy(xpath="/html/body/app-bc-oauth/bc-user-page/section/div/bc-oauth-input/div/input")
	private WebElement txtusuario;
	
    @FindBy(xpath="/html/body/app-bc-oauth/bc-pwd-page/section/div/bc-oauth-input/div/input")
	private WebElement txtcontrasena;
    
    @FindBy(xpath="/html/body/app-bc-oauth/bc-user-page/section/div/div[2]/bc-oauth-button/div")
	private WebElement btnContinuar;
    					
    @FindBy(xpath ="/html/body/app-bc-oauth/bc-pwd-page/section/div/div[3]/bc-oauth-button[2]/div")
    private WebElement btnIngresar;
    
    @FindBy(id ="usuario")
    private WebElement txtusuariomock;
    

    @FindBy(id ="clave")
    private WebElement txtcontrasenamock;
    
    @FindBy(xpath = "/html/body/div[3]/form/div[3]/div/input")
    private WebElement btnEntrar;
      
    @WhenPageOpens
    public void waitUntilMainElementsAppears() {
        getDriver().manage().window().maximize();
    }
    
    
	public void Autenticacionoauth(String Usuario, String Contrasena)throws InterruptedException {
		
		
		txtusuario.sendKeys(Usuario);
//		txtusuariomock.sendKeys(Usuario);
//		txtcontrasenamock.sendKeys(Contrasena);	
		btnContinuar.click();		
		Thread.sleep(6000);
		tecladoDinamico(Contrasena);
		Thread.sleep(6000);
		btnIngresar.click();
			
	}

	
	public void tecladoDinamico(String clave) {
        
        char [] numeros = clave.toCharArray();
        By mySelector = By.cssSelector("div.bc-keyboard-button.bc-keyboard-button-contrast-2");        
        List<WebElement> myElements = getDriver().findElements(mySelector);
    
        for(int i= 0; i < numeros.length; i++) {
            
            for(WebElement e : myElements) {
                char num = e.getText().charAt(0);
                
                if(num == numeros[i]) {
                    e.click();                
                }
            }
        }
    
    }


}
