package com.bancolombia.preaprobado.libreinversion.definitions;


import com.bancolombia.preaprobado.libreinversion.steps.AutenticaSteps;
import com.bancolombia.preaprobado.libreinversion.utilities.ConexionOracle;
import com.bancolombia.preaprobado.models.CredencialesTasasOracle;
import com.bancolombia.preaprobado.models.TasasLibreInversion;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class AutenticaDefinitions {
	
	
	
	@Steps
	AutenticaSteps autenticacionoauth;
	
	private String segmento,grupoRiesgo,plan;
	private int plazo, monto;
	
	@Given("^que me encuentro en la autenticacion oauth de Libre Inversión$")
	public void que_me_encuentro_en_la_autenticacion_oauth_de_Libre_Inversión() throws Exception {
	   //String path = Serenity.sessionVariableCalled("C:\\Users\\Usuario.DESKTOP-HN86BQH\\Desktop\\dtDatos.xlsx").toString();
		autenticacionoauth.abrirAutentica();
	}


	@When("^Ingreso los datos de \"([^\"]*)\" y \"([^\"]*)\"$")
	public void ingreso_los_datos_de_y(String Usuario, String Contrasena) throws Exception {
	   
		autenticacionoauth.ingresarDatos(Usuario, Contrasena);
	}
	
	@When("^verifico el limite \"([^\"]*)\"$")
	public void verifico_el_limite(String strDocumento) throws Exception {
		autenticacionoauth.Consulta_CNAME(strDocumento);
		autenticacionoauth.Armar_Query_Consulta_XCRL();
	}

//	@When("^Seleccionar producto credito libre inversion$")
//	public void seleccionar_producto_credito_libre_inversion() throws Exception {
//	    
//		autenticacionoauth.clicbotonIngresar();
//	}

	@When("^Solicitar credito de libre inversion$")
	public void solicitar_credito_de_libre_inversion() throws Exception {
	   
		autenticacionoauth.clicbotonSolcitar();
	}

	@When("^Ingresar  datos de \"([^\"]*)\" y \"([^\"]*)\"$")
	public void ingresar_datos_de_y(String Cupo, String Plazo) throws Exception {
		String [] StrPlazo = Plazo.split(" ");
	    String plazos=StrPlazo[0];
	    String montos= Cupo;
		autenticacionoauth.calcularCuota(montos, plazos);
		
		this.plazo= Integer.parseInt(plazos);
		this.monto= Integer.parseInt(montos);
		autenticacionoauth.validarTasas(TasasLibreInversion.consultar(ConexionOracle.deTasas(CredencialesTasasOracle.delProperties().getUser(), CredencialesTasasOracle.delProperties().getPass()).
		llamadoAlProcedimiento("BIZ", plan, segmento, grupoRiesgo, monto, plazo), plazo, monto));
	}
	
	@When("^esta en la pantalla del oferta con las caracteristicas S(\\d+) G(\\d+) P(\\d+)$")
	public void esta_en_la_pantalla_del_oferta_con_las_caracteristicas_S_G_P(String segmento, String grupoRiesgo, String plan) throws Exception {
		  this.segmento=segmento;
		  this.grupoRiesgo=grupoRiesgo;
		  this.plan=plan;
	}

	@When("^Definir cuenta \"([^\"]*)\"$")
	public void definir_cuenta_y(String Desembolso) throws Exception {
	    
		autenticacionoauth.seleccionarNumerodeCuenta(Desembolso);
	}
	
	@When("^Desea usar debito automatico (.*) y cuenta \"([^\"]*)\"$")
	public void desea_usar_debito_automatico_y_cuenta(String Desicion, String Debito) throws Exception {
	    
		autenticacionoauth.usarServicioAutomatico(Desicion, Debito);
	}

	@When("^Verpagare y documentos$")
	public void verpagare_y_documentos() throws Exception {
		autenticacionoauth.verPagareydocumentos();
	 
	}
	
	
    @When("^Aceptar \"([^\"]*)\"$")
	public void aceptar_si_y_y_no(String Seguro) throws Exception {
	   
		autenticacionoauth.aceptarSeguro(Seguro);
	}
    
    @When("^Devolverclavedinamica \"([^\"]*)\"$")
    public void devolverclavedinamica(String strDocumento) throws Exception {
    	autenticacionoauth.Consulta_Clave_Dinamica(strDocumento);
    }

	@Then("^Verificar solicitud exitosa de credito$")
	public void verificar_solicitud_exitosa_de_credito() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		autenticacionoauth.finalizarcontenido();
	}	
	
	
	@Then("^Calificar la experiencia$")
	public void calificar_la_experiencia() throws Exception {
		autenticacionoauth.calificatuexperiencia();
	
	}
	
//	@Then("^Vuelvo a verificar el limite \"([^\"]*)\"$")
//	public void vuelvo_a_verificar_el_limite(String strDocumento) throws Exception {
//		autenticacionoauth.Consulta_CNAME(strDocumento);
//		autenticacionoauth.Armar_Query_Consulta_XCRL_limite();
//	 
//	}

	@Then("^Solicitud Realizada$")
	public void solicitud_Realizada() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^Regresar al dashboard$")
	public void regresar_al_dashboard() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    
	}


}
