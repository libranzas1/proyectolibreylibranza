package com.bancolombia.preaprobado.libreinversion.pages;

import org.apache.tools.ant.taskdefs.Sleep;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;

public class RequisitosPages extends PageObject {

	@FindBy(className = "img-product")
	private WebElement btnempieza;
	
	@FindBy(xpath ="//div[@ng-class='idProductoImagen']")
	private WebElement imgSolicitarCredito;
	

	public void presionarBotonSolicitarCredito() throws Exception {
		
		Thread.sleep(10000);
		JavascriptExecutor executor =(JavascriptExecutor)getDriver();
		executor.executeScript("window.scrollBy(0,350)", "");	
		waitABit(3000);
		btnempieza.click();
		Thread.sleep(8000);
	}
	
}
