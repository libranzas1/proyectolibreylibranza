package com.bancolombia.preaprobado.libreinversion.definitions;

import java.util.List;

import com.bancolombia.preaprobado.libreinversion.steps.AutenticaSteps;
import com.bancolombia.preaprobado.libreinversion.utilities.ExcelReader;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Steps;

public class BackiendAs400db2PccffdgalDefinitions {
	private String archivo = "C://Users//UserQV//Documents//Archivos_Automatizaciones//correo_tel.xlsx";
 	private String hoja = "Sheet1"; 
 	
	@Steps
	AutenticaSteps AutenticaSteps;

	@Given("^valido los datos de PCCFFDGAL$")
	public void valido_los_datos_de_PCCFFDGAL(DataTable Documento) throws Exception {
		AutenticaSteps.ProcesoExcel(archivo, hoja);
		
		List<List<String>> dato = Documento.raw();
		for(int i=0; i<dato.size(); i++){
			AutenticaSteps.ConsultaTelynombre(dato, i);
		}
	   
		ExcelReader.SaveData(archivo);
	}

	
}
