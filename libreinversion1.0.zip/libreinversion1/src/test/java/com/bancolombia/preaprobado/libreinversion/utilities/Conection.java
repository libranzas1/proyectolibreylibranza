package com.bancolombia.preaprobado.libreinversion.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import javax.swing.JOptionPane;

public class Conection {

	private static Conection instance;
	private String user;
	private String password;
	private String name_host;
	private String puerto;
	private String sid;
	private String userTasas;
	private String passwordTasas;
	private String name_hostTasas;
	private String user_bizagi;
	private String password_bizagi;
	private String name_host_bizagi;
	private String puerto_bizagi;
	private String sid_bizagi;

//		 cb.driver=oracle.jdbc.driver.OracleDriver
	private Conection() {
		inicialice();
	}

	private void inicialice() {
		try {
			Properties prop = new Properties();
			prop.load(new FileReader("C:\\Workspace2\\libreinversion\\dbConfig.properties"));
			// Prpiedades Precalculado
			this.user = prop.getProperty("cb.user");
			this.password = prop.getProperty("cb.password");
			this.name_host = prop.getProperty("cb.name_host");
			this.puerto = prop.getProperty("cb.puerto");
			this.sid = prop.getProperty("cb.sid");
			// Prpiedades Tasas
			this.userTasas = prop.getProperty("tb.user");
			this.passwordTasas = prop.getProperty("tb.password");
			this.name_hostTasas = prop.getProperty("tb.name_host");
			// Prpiedades Bizagi
			this.user_bizagi = prop.getProperty("bb.user");
			this.password_bizagi = prop.getProperty("bb.password");
			this.name_host_bizagi = prop.getProperty("bb.name_host");
			this.puerto_bizagi = prop.getProperty("bb.puerto");
			this.sid_bizagi = prop.getProperty("bb.sid");

			Class.forName(prop.getProperty("cb.driver"));

		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	// aplicando Singleton
	public static Conection getInstance() {
		if (instance == null)
			instance = new Conection();
		return instance;
	}

	public Connection getConeccion() throws SQLException {
		Connection con = DriverManager.getConnection(this.name_host, this.user, this.password);
		// JOptionPane.showInputDialog(con);
		return con;
	}
// CONEXION TASAS
	public Connection getConectionTasas() throws SQLException  {
		Connection con = DriverManager.getConnection(this.name_hostTasas, this.userTasas, this.passwordTasas);
		return con;
	}
	
	

}
