package com.bancolombia.preaprobado.libreinversion.pages;

import java.io.FileNotFoundException;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;

public class DocumentosPages extends PageObject {
	
	BackendAs400db2Page backendAs400db2Page;
	
	@FindBy(id = "pagare")
	private WebElement checpagare;
	
	@FindBy(id ="aceptarSeguro")
	private WebElement aceptarSeguro;
	
	@FindBy(id ="noAceptarSeguro")
	private WebElement noaceptarSeguro;
	
	@FindBy(id ="linkPagareId")
	private WebElement linkpagare;
	
	@FindBy(id ="inputCodigoOTP")
	private WebElement txtcodigoOtp;
	
	@FindBy(id ="finalizar")
	private WebElement btnFinalizar;
	
	@FindBy (xpath ="//*[@id=\"modalReclamacion\"]/div/div/div/div[2]/div[2]/button")
	private WebElement btnnoaceptarSeguro;
	
	@FindBy (id ="cancelarBtnId")
	private WebElement btnaceptarSeguro;
	
	public void verPagareydocumentos() throws  InterruptedException{
		evaluateJavascript("arguments[0].click();",getDriver().findElement(By.id("pagare")));
		Thread.sleep(2000);		
	}

	
	public void aceptarSeguro(String Seguro) throws  InterruptedException {
		 evaluateJavascript("arguments[0].click();",getDriver().findElement(By.id("aceptarSeguro")));
		//evaluateJavascript("arguments[0].click();",getDriver().findElement(By.id("noaceptarSeguro")));
	
	}
	
	public void claveDinamica(String Documento)throws  InterruptedException, SQLException, FileNotFoundException {
		 Thread.sleep(3000);     
		 
		 	String query = backendAs400db2Page.Consultar_Clave_Dinamica(Documento);
			ResultSet rs = backendAs400db2Page.Ejecutar_Query(query);	
					 
		 txtcodigoOtp.sendKeys(backendAs400db2Page.Obtener_Clave_Dinamica(rs));
		 Thread.sleep(3000);
		 btnFinalizar.click();
		 Thread.sleep(50000);
				
	}
		
}
