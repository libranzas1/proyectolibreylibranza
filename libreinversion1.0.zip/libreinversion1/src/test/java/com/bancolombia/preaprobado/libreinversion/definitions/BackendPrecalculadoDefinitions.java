package com.bancolombia.preaprobado.libreinversion.definitions;

import com.bancolombia.preaprobado.libreinversion.steps.AutenticaSteps;
import com.bancolombia.preaprobado.libreinversion.steps.BackendAs400db2Steps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class BackendPrecalculadoDefinitions {
	
	@Steps
	AutenticaSteps AutenticaSteps;
	
	@Given("^valido los datos del precalculado (\\d+)$")
	public void valido_los_datos_del_precalculado(String strDocumento) throws Exception {
		AutenticaSteps.Armar_Query_Consulta_Precalculado(strDocumento);
	  
	}


}
