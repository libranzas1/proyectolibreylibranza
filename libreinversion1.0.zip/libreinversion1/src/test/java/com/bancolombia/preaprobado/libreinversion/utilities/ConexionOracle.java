package com.bancolombia.preaprobado.libreinversion.utilities;

import java.io.FileReader;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Properties;

import com.bancolombia.preaprobado.models.Tipos;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

public class ConexionOracle {
	
	ArrayList<Tipos> misTipos= new ArrayList<>();
	
	public static Connection con;
	public static Statement sen;
	public static ResultSet res;
	public static String url = "jdbc:oracle:thin:@PBMDEBQADB01:1525:ADTASQDB";
	
	public static ConexionOracle deTasas(String user, String pass) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.OracleDriver").newInstance();
		con = DriverManager.getConnection(url, user, pass);
		return new ConexionOracle();
	}
	
	public ResultSet llamadoAlProcedimiento(String canal, String plan, String segmento,String grupoRiesgo
											,int monto, int plazo) throws SQLException {

		CallableStatement stamento = con.prepareCall("{call SCHADTAS.GET_CALCULATE_RATE(?,?,?,?,?,?,?,?,?)}");
		stamento.registerOutParameter(1, Types.VARCHAR);
		stamento.registerOutParameter(2, Types.VARCHAR);
		stamento.registerOutParameter(3, OracleTypes.CURSOR);
		stamento.setString(4, canal);
		stamento.setString(5, plan);
		stamento.setString(6, segmento);
		stamento.setString(7, grupoRiesgo);
		stamento.setDouble(8, monto);
		stamento.setDouble(9, plazo);
		stamento.execute();
		return ((OracleCallableStatement) stamento).getCursor(3);
	}
	
	
	
//	public ResultSet llamandoAlProcedimiento(String procedimiento, ArrayList<Tipos> misTipos) throws SQLException {
//		CallableStatement stamento = con.prepareCall(procedimiento);
//		for (Tipos tipo : misTipos) {
//			switch (tipo.getType()) {
//			case "input":
//				stamento.setString(tipo.getIndicador(),(String) tipo.getValue());
//				break;
//			case "output":
//				stamento.registerOutParameter(tipo.getIndicador(), tipo.getTipo());
//				break;
//			default:
//				break;
//			}
//		}
//	}
}