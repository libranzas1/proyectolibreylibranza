package com.bancolombia.preaprobado.libreinversion.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.ibm.icu.impl.Assert;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class OfertaPages extends PageObject {
	
	
	@FindBy(id = "montoSolicitadoLibreInversion")
	private WebElement txtCupoasolicitar;
	
	@FindBy(id ="slctplazoCredito")
    private WebElementFacade listplazo;
	
	@FindBy(id ="calcularCuotaBotonId")
	private WebElement btncalcular;
	
	@FindBy (id ="cuenta")
	private WebElementFacade listdesembolso;
	
	@FindBy (id ="cuentaDebito")
	private WebElementFacade listdebito;
	
	@FindBy (id ="continuarPagina1FPLIBtnId")
	private WebElement btncontinuar;
	
	@FindBy (id ="debitoAutomatico")
	private WebElement radiobutoyes;
	
	@FindBy (id ="noDebitoAutomatico")
	private WebElement radiobutono;
	
	@FindBy (xpath="//*[@id='content']/div/form/div[13]/div[2]/p")
    private WebElement labelText;
	
	@FindBy (className=".m0000.xs-text-center.ng-binding")
	private WebElement labelNombreText;
	
	@FindBy (xpath="//*[@id=\"content\"]/div/form/div[6]/div[2]/div/div[2]/div[2]/div[2] \r\n")
	private WebElement lblTasaNAMV;
	public double leerTasaNAMV() {
		return Double.parseDouble(lblTasaNAMV.getText());
	}
	
	@FindBy (xpath="//*[@id=\"content\"]/div/form/div[6]/div[2]/div/div[2]/div[3]/div[2]")
	private WebElement lblTasaEA;
	public double leerTasaEA() {
		return Double.parseDouble(lblTasaEA.getText());
	}
	
	@FindBy (xpath="//*[@id=\"content\"]/div/form/div[6]/div[2]/div/div[2]/div[4]/div[2] ")
	private WebElement lblTasaMora;
	
	public double leerTasaMora() {
		return Double.parseDouble(lblTasaMora.getText());
	}
	
	@FindBy(xpath="//*[@id=\"content\"]/div/form/div[6]/div[2]/div/div[1]/div[5]")
	private WebElement lblTasaMV;
	
	public double leerTasaMV() {
		return Double.parseDouble(lblTasaMV.getText());
	}

String cuenta;

	 public void calcularCuota(String Cupo, String Plazo) throws InterruptedException {
		    txtCupoasolicitar.sendKeys(Cupo);
		    listplazo.selectByVisibleText(Plazo);
		    Thread.sleep(2000);
		    btncalcular.click();
		    Thread.sleep(3000);
		    JavascriptExecutor executor =(JavascriptExecutor)getDriver();
			executor.executeScript("window.scrollBy(0,300)", "");	
			Thread.sleep(3000);
	    } 
	
	 public void seleccionarNumerodeCuenta(String Desembolso) throws InterruptedException {
		    listdesembolso.selectByVisibleText(Desembolso);
		    Thread.sleep(3000);
		   
	    } 
	 
	 public void usarServicioAutomatico(String Desicion, String Debito)throws InterruptedException {
		 if (Desicion.equals("si")) {
			 evaluateJavascript("arguments[0].click();",getDriver().findElement(By.id("debitoAutomatico")));
//			 Thread.sleep(3000);
			 cuenta =labelText.getText();		 
//			 listdebito.selectByVisibleText(Debito);
			
		     btncontinuar.click();
		   
		     
		 }else if(Desicion.equals("no")) {
			 //JavascriptExecutor executor =(JavascriptExecutor)getDriver();
			 evaluateJavascript("arguments[0].click();",getDriver().findElement(By.id("noDebitoAutomatico")));
			 Thread.sleep(3000);
			 btncontinuar.click();
		 }
		 
		 Thread.sleep(30000);
	   }	 
}
