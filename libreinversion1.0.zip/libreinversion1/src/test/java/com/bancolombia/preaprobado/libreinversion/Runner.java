package com.bancolombia.preaprobado.libreinversion;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;

@RunWith(CucumberWithSerenity.class)
//@CucumberOptions(
//  features = { "classpath:features/autenticacion/autenticar.feature" },
//  glue = {"com.bancolombia.preaprobado.libreinversion.definitions" })
@CucumberOptions(features="src/test/resources/features/Test_Front_LI/ExperienciaPreaprobadosLI.feature")
//@CucumberOptions(features="src/test/resources/features/Test_Back_LI/ConsultaIseries.feature",tags="@ValidacionLogdeprueba")
//@CucumberOptions(features="src/test/resources/features/Test_Back_LI/Preaprobados.feature",tags="@ValidacinTablaPrecalculado")
//@CucumberOptions(features="src/test/resources/features/Test_Back_LI/Clave_dinamica.feature",tags="@Validacionclavedinamica")
//@CucumberOptions(features="src/test/resources/features/Test_Back_LI/ConsultarCname.feature",tags="@Validacionnombre")
//@CucumberOptions(features="src/test/resources/features/Test_Back_LI/ConsultaPCCFFDGAL.feature",tags="@Validaciontelycorreo")
public class Runner {
	
}
