package com.bancolombia.certificacion.libranzas.consultas.stepdefinitions;

import com.bancolombia.certificacion.libranzas.consultasback.tasks.Conectarse;
import com.bancolombia.certificacion.libranzas.consultasback.tasks.CapturarCNAME;
import static com.bancolombia.certificacion.libranzas.consultasback.tasks.CapturarCNAME.strLLaveNombre;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.Actor;

public class CapturarLimiteInicioDefinition {

	public Actor actor;
	
	@Given("^consulto el archivo CNAME y capturo la llave nombre$")
	public void consultoElArchivoCNAMEYCapturoLaLlaveNombre() {
		actor = actor.named("Back");
		actor.attemptsTo(Conectarse.conIseries().conElQuery("SELECT CNNAMK, CNSNAM  FROM VISIONR.CNAME WHERE CNNOSS ='000018062995619' ORDER BY CNNAMK"),
				CapturarCNAME.datosConsultados());
	}

	@When("^consulto el archivo XCRL$")
	public void consultoElArchivoXCRL() {
		System.out.println(strLLaveNombre);
//		actor.attemptsTo(Conectarse.conIseries().conElQuery("SELECT XCNAMK, XCNOSQ, XCCDCT,XCCDAC, XCAMAP,XCAMTT, XCAMTD,XCDTLM FROM VISIONR.XCRL WHERE XCNAMK  =strLLaveNombre AND XCCDCT ='OPE' AND XCCDAC='1' ORDER BY XCNAMK"));

	}

	@Then("^capturo el dato del limite$")
	public void capturoElDatoDelLimite() {
		
	}

}
