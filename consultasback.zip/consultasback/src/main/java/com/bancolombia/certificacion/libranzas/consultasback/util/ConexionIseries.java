package com.bancolombia.certificacion.libranzas.consultasback.util;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class ConexionIseries {

	public static Connection con;
	public static PreparedStatement sen;
	public static ResultSet res, rs;
	private String user;
	private String password;
	private String url;
	private String datosConsulta;
	
	public ConexionIseries() {
		try {
			Properties prop = new Properties();
			prop.load(new FileReader("C:\\Users\\1532180\\workspace-libranzas\\consultasback\\bdconfig.properties"));
			this.user = prop.getProperty("db.user");
			this.password=prop.getProperty("db.password");
			this.url=prop.getProperty("db.url");
			Class.forName(prop.getProperty("db.driver"));
			
			con = DriverManager.getConnection(this.url, this.user, this.password);
			System.out.println("Conexion exitosa iSeries");
		} catch (Exception e) {
			System.out.println("Error" + e);
		}
	}
	
	public static ConexionIseries conCredenciales() {
		return new ConexionIseries();
	}
	
	public ResultSet haceConsulta(String strQuery) {
		try {
			System.out.println(" ");
			System.out.println(strQuery);
			sen = con.prepareStatement(strQuery);
			rs=sen.executeQuery();
			return rs;
					
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public static void muestraDatos() throws SQLException{
		while(rs.next())
		{
			System.out.println(rs.getString(1));
		}
	}
	
}
