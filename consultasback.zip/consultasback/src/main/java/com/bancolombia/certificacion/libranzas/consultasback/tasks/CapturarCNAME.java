package com.bancolombia.certificacion.libranzas.consultasback.tasks;

import static com.bancolombia.certificacion.libranzas.consultasback.util.ConexionIseries.rs;

import java.sql.SQLException;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;

public class CapturarCNAME implements Task {

	public static String strLLaveNombre;
	public static String strNombreCorto;

	@Override
	public <T extends Actor> void performAs(T actor) {

		try {

			while (rs.next()) {

				strLLaveNombre = rs.getString(1);
				strNombreCorto = rs.getString(2);
				System.out.println(strLLaveNombre);
				System.out.println(strNombreCorto);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static CapturarCNAME datosConsultados() {
		return new CapturarCNAME();
	}

	public String devolverLLaveNombre() {
		return strLLaveNombre;
	}
	
	public String devolverNombreCorto() {
		return strNombreCorto;
	}

}
