package com.bancolombia.certificacion.libranzas.consultasback.tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;

public class CapturarXCRL implements Task {

	public static String strLlaveNombreCNAME, strNumeroSecuencial, strMontoAprobado, strMontoRetirosHoy,
			strMontoTotalRetiros, strFechaUltimoManteni;

	@Override
	public <T extends Actor> void performAs(T actor) {
		// TODO Auto-generated method stub

	}

}
