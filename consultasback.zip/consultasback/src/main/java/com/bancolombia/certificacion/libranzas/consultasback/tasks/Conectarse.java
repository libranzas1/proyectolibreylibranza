package com.bancolombia.certificacion.libranzas.consultasback.tasks;

import com.bancolombia.certificacion.libranzas.consultasback.util.ConexionIseries;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;

public class Conectarse implements Task {
	
	private String strQuery;

	@Override
	public <T extends Actor> void performAs(T actor) {
		actor.remember("consulta iseries", ConexionIseries.conCredenciales().haceConsulta(strQuery));
		
	}
	
	public static Conectarse conIseries() {
		return new Conectarse();
	}
	
	public Conectarse conElQuery(String strQuey) {
		this.strQuery=strQuey;
		return this;
	}

}
